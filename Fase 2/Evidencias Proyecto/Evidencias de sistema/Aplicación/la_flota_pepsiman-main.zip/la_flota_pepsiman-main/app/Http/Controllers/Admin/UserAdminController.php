<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Usuario;
use App\Models\Role;
use App\Models\Vehiculo;
use App\Models\VehiculoChofer;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class UserAdminController extends Controller
{
    public function index(Request $request)
    {
        $roles = Role::all();

        $rol = $request->input('rol');        
        $q   = trim((string) $request->input('q', ''));

        $usuarios = Usuario::with('roles')
            ->when($rol, function ($query) use ($rol) {
                $query->whereHas('roles', function ($q2) use ($rol) {
                    $q2->where('roles.rol_id', $rol);
                });
            })
            ->when($q !== '', function ($query) use ($q) {
                $like = '%'.$q.'%';
                $query->where(function ($qq) use ($like) {
                    $qq->where('usuario_nombre', 'LIKE', $like)
                        ->orWhere('usuario_email',  'LIKE', $like);
                });
            })
            ->get();

        return view('vista_admin_usuario', compact('roles', 'usuarios', 'rol', 'q'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'usuario_nombre'   => 'required|string|max:255',
            'usuario_email'    => 'required|email|unique:usuarios,usuario_email',
            'usuario_password' => ['required', 'confirmed', Password::min(8)->letters()->numbers()->symbols()],
            'usuario_estado'   => 'required|boolean',
            'roles'            => 'required|array',
            'roles.*'          => 'integer|exists:roles,rol_id',
            'usuario_telefono' => 'nullable|string|max:30',
        ]);

        DB::beginTransaction();
        try {
            $usuario = Usuario::create([
                'usuario_nombre'   => $validated['usuario_nombre'],
                'usuario_email'    => $validated['usuario_email'],
                'usuario_password' => Hash::make($validated['usuario_password']),
                'usuario_estado'   => $validated['usuario_estado'],
                'usuario_telefono' => $request->input('usuario_telefono'),
            ]);

            $usuario->roles()->attach($validated['roles']);

            DB::commit();

            return redirect()
                ->route('admin.usuarios.index')
                ->with('success', 'Usuario creado correctamente.');
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->withInput()
                ->with('error', 'Error al crear el usuario: '.$e->getMessage());
        }
    }

    public function destroy($id)
    {
        $usuario = Usuario::with('roles')->findOrFail($id);

        $rolesEliminables = ['Chofer', 'Guardia', 'Recepcionista'];

        DB::beginTransaction();
        try {
            $tieneRolEliminable = $usuario->roles->contains(function ($rol) use ($rolesEliminables) {
                return in_array($rol->rol_nombre, $rolesEliminables);
            });

            if ($tieneRolEliminable) {
                // --- Cerrar asignaciones abiertas (no tocar FK) ---
                VehiculoChofer::where('usuario_id', $usuario->usuario_id)
                    ->whereNull('hasta_ts')
                    ->update([
                        'hasta_ts' => now(),
                        'motivo'   => 'Cierre por eliminación de usuario',
                    ]);

                // --- Quitar relación directa del vehículo ---
                Vehiculo::where('usuario_id', $usuario->usuario_id)
                    ->update(['usuario_id' => null]);

                $usuario->roles()->detach();
                $usuario->delete();

                $accion = 'Usuario eliminado correctamente.';

            } else {
                // Solo desactivar
                $usuario->update(['usuario_estado' => 0]);
                $accion = 'Usuario desactivado correctamente.';
            }

            DB::commit();
            return redirect()
                ->route('admin.usuarios.index')
                ->with('success', $accion);

        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()
                ->back()
                ->with('error', 'Error al eliminar o desactivar el usuario: ' . $e->getMessage());
        }
    }


    public function update(Request $request, $id)
    {
        $usuario = Usuario::with('roles')->findOrFail($id);

        $estadoOriginal = (int) $usuario->usuario_estado;

        $rules = [
            'usuario_nombre'   => 'required|string|max:255',
            'usuario_email'    => 'required|email|unique:usuarios,usuario_email,' . $usuario->usuario_id . ',usuario_id',
            'usuario_telefono' => 'nullable|string|max:50',
            'usuario_estado'   => 'nullable|boolean',
            'roles'            => 'required|array|min:1',
        ];

        if ($estadoOriginal === 0 && (int)$request->input('usuario_estado') === 1) {
            $rules['usuario_password'] = [
                'required', 'confirmed',
                Password::min(8)->letters()->numbers()->symbols(),
            ];
        }

        $validated = $request->validate($rules);

        $usuario->usuario_nombre   = $validated['usuario_nombre'];
        $usuario->usuario_email    = $validated['usuario_email'];
        $usuario->usuario_telefono = $request->input('usuario_telefono');
        if (array_key_exists('usuario_estado', $validated)) {
        $usuario->usuario_estado = (int) $validated['usuario_estado'];
        }

        if (array_key_exists('usuario_password', $validated)) {
            if (!empty($usuario->usuario_password) &&
                Hash::check($validated['usuario_password'], $usuario->usuario_password)) {
                return back()->with('error', 'La nueva contraseña no puede ser igual a la actual.');
            }
            $usuario->usuario_password = Hash::make($validated['usuario_password']);
        }

        $usuario->save();
        $usuario->roles()->sync($validated['roles']);

        return back()->with('success', 'Usuario actualizado correctamente.');
    }

    public function show($id)
    {
        $usuario = Usuario::with('roles')->findOrFail($id);

        return response()->json([
            'usuario_nombre'   => $usuario->usuario_nombre,
            'usuario_email'    => $usuario->usuario_email,
            'usuario_telefono' => $usuario->usuario_telefono,
            'usuario_estado'   => $usuario->usuario_estado,
            'roles'            => $usuario->roles->pluck('rol_nombre')->toArray(),
            'created_at'       => $usuario->created_at ? $usuario->created_at->format('d/m/Y H:i') : '—',
        ]);
    }

    public function resetPassword(Request $request, $id)
    {
        $request->validate([
            'usuario_password' => ['required','confirmed', Password::min(8)->letters()->numbers()->symbols()],
        ]);

        $usuario = Usuario::findOrFail($id);

        if (!empty($usuario->usuario_password) &&
            Hash::check($request->usuario_password, $usuario->usuario_password)) {
            return back()->with('error', 'La nueva contraseña no puede ser igual a la actual.');
        }

        $usuario->usuario_password = Hash::make($request->input('usuario_password'));
        $usuario->save();

        return redirect()
            ->route('admin.usuarios.index')
            ->with('success', 'Contraseña actualizada correctamente.');
    }

    public function asignarChofer(Request $request)
    {
        $data = $request->validate([
            'vehiculo_id' => ['required','integer','exists:vehiculos,vehiculo_id'],
            'usuario_id'  => ['required','integer','exists:usuarios,usuario_id'],
        ]);

        $vehiculo = Vehiculo::findOrFail($data['vehiculo_id']);
        $chofer   = Usuario::with('roles')->findOrFail($data['usuario_id']);

        if ($vehiculo->estado_vehiculo === 'baja') {
            return $request->wantsJson()
                ? response()->json(['success'=>false,'message'=>'No se puede asignar chofer a un vehículo dado de baja.'], 422)
                : back()->with('error', 'No se puede asignar chofer a un vehículo dado de baja.');
        }

        $esChofer = $chofer->roles()->where('rol_nombre', 'Chofer')->exists();
        if (!$esChofer) {
            return $request->wantsJson()
                ? response()->json(['success'=>false,'message'=>'El usuario no tiene rol de Chofer.'], 422)
                : back()->with('error', 'El usuario seleccionado no tiene el rol de Chofer.');
        }
        if (method_exists($chofer, 'getAttribute') && $chofer->getAttribute('usuario_estado') === 0) {
            return $request->wantsJson()
                ? response()->json(['success'=>false,'message'=>'El chofer está inactivo.'], 422)
                : back()->with('error', 'El chofer está inactivo.');
        }

        if ((int) $vehiculo->usuario_id === (int) $chofer->usuario_id) {
            return $request->wantsJson()
                ? response()->json(['success'=>true,'message'=>'El chofer ya estaba asignado.'])
                : back()->with('success', 'El chofer ya estaba asignado a este vehículo.');
        }

        DB::beginTransaction();
        try {
            VehiculoChofer::where('vehiculo_id', $vehiculo->vehiculo_id)
                ->whereNull('hasta_ts')
                ->update([
                    'hasta_ts' => now(),
                    'motivo'   => 'Reasignación de chofer',
                ]);
            VehiculoChofer::where('usuario_id', $chofer->usuario_id)
                ->whereNull('hasta_ts')
                ->update([
                    'hasta_ts' => now(),
                    'motivo'   => 'Reasignación a otro vehículo',
                ]);
            Vehiculo::where('usuario_id', $chofer->usuario_id)
                ->where('vehiculo_id', '!=', $vehiculo->vehiculo_id)
                ->update(['usuario_id' => null]);

            $vehiculo->update([
                'usuario_id' => $chofer->usuario_id,
            ]);

            VehiculoChofer::create([
                'vehiculo_id' => $vehiculo->vehiculo_id,
                'usuario_id'  => $chofer->usuario_id,
                'desde_ts'    => now(),
                'motivo'   => 'Asignación inicial', 
            ]);

            DB::commit();

            if ($request->wantsJson()) {
                return response()->json(['success'=>true,'message'=>'Chofer asignado correctamente.']);
            }
            return back()->with('success', 'Chofer asignado correctamente.');
        } catch (\Throwable $e) {
            DB::rollBack();
            if ($request->wantsJson()) {
                return response()->json(['success'=>false,'message'=>'Error al asignar chofer: '.$e->getMessage()], 500);
            }
            return back()->with('error', 'No se pudo asignar el chofer: '.$e->getMessage());
        }
    }

    public function toggleState(Request $request, $id)
    {
        $usuario = Usuario::with('roles')->findOrFail($id);

        //  Estos roles NO se activan/inactivan: se eliminan desde destroy()
        $rolesEliminables = ['Chofer','Guardia','Recepcionista'];
        $tieneRolEliminable = $usuario->roles->contains(fn($r) => in_array($r->rol_nombre, $rolesEliminables));
        if ($tieneRolEliminable) {
            return back()->with('error', 'Este tipo de usuario no se activa/desactiva. Se elimina desde la opción Eliminar.');
        }

        //  Validación base
        $data = $request->validate([
            'usuario_estado'  => ['required','boolean'], 
            // password será requerida si reactivamos (se valida abajo)
            'usuario_password' => ['nullable','confirmed'],
        ]);

        $from = (int) $usuario->usuario_estado;
        $to   = (int) $data['usuario_estado'];

        if ($from === $to) {
            return back()
                ->with('open_modal', 'toggle')
                ->with('toggle_error', 'El estado ya estaba establecido.')
                ->withInput();
        }
        // 3) Si reactivamos (0→1): exigir contraseña fuerte y distinta a la actual
        if ($from === 0 && $to === 1) {
            $request->validate([
                'usuario_password' => [
                    'required',
                    'confirmed',
                    Password::min(8)->letters()->numbers()->symbols(),
                ],
            ]);

            // No permitir reutilizar contraseña
            if (!empty($usuario->usuario_password) &&
                Hash::check($request->usuario_password, $usuario->usuario_password)) {
                return back()
                    ->with('open_modal', 'toggle')
                    ->with('toggle_error', 'La nueva contraseña no puede ser igual a la anterior.')
                    ->withInput();
            }

            $usuario->usuario_password = Hash::make($request->usuario_password);
            $usuario->usuario_estado   = 1;
            $usuario->save();

            return back()->with('success', 'Cuenta reactivada y contraseña actualizada.');
        }

        // 4) Si desactivamos (1→0)
        if ($from === 1 && $to === 0) {
            $usuario->update(['usuario_estado' => 0]);
            return back()->with('success', 'Cuenta desactivada correctamente.');
        }

        // 5) Cualquier otro caso
        return back()->with('error', 'Transición de estado no válida.');
    }






}