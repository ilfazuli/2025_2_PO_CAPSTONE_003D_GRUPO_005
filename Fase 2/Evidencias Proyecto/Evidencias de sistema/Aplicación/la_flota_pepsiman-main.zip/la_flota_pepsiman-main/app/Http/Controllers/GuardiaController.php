<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agendamiento;
use App\Models\Checkin;
use App\Models\Vehiculo;
use Carbon\Carbon;

class GuardiaController extends Controller
{
    public function index(Request $request)
    {
        // Fecha de trabajo (hoy por defecto)
        $fecha = $request->input('fecha', now()->toDateString());

        // Reservas del día (citas que deberían llegar hoy)
        $reservas = Agendamiento::with(['vehiculo', 'usuario'])
            ->whereDate('fecha', $fecha)
            ->orderBy('hora_inicio')
            ->get();

        //  Vehículos actualmente en taller (ingreso hecho y SIN salida)
        $ingresos = Checkin::with(['vehiculo.chofer', 'guardia', 'agendamiento'])
            ->whereDate('ingreso_ts', $fecha)
            ->whereNull('salida_ts')
            ->orderBy('ingreso_ts')
            ->get();

        // Historial de ingresos de hoy (con salida registrada)
        $historial = Checkin::with(['vehiculo.chofer', 'guardia', 'agendamiento'])
            ->whereDate('ingreso_ts', $fecha)
            ->whereNotNull('salida_ts')
            ->orderByDesc('salida_ts')
            ->get();

        $reservasHoy = $reservas;

        return view('vista_guardia', compact(
            'reservas',
            'reservasHoy',
            'ingresos',
            'historial',
            'fecha'
        ));
    }

    /**
     * Registrar INGRESO de vehículo (cuando el guardia usa "+ Agregar vehículo").
     * Además marca estado_recepcion = 'PENDIENTE' para que el recepcionista lo vea.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'patente'         => 'required|string|max:20',
            'hora_entrada'    => 'required|date_format:H:i',
            'agendamiento_id' => 'nullable|integer|exists:agendamientos,agendamiento_id',
            'fotos.*'         => 'nullable|image|max:5120',
        ]);

        $vehiculo = Vehiculo::where('vehiculo_patente', $data['patente'])->first();

        $fotos = [];
        if ($request->hasFile('fotos')) {
            foreach ($request->file('fotos') as $f) {
                $fotos[] = $f->store('checkins', 'public');
            }
        }

        $ingresoTs = Carbon::today()->setTimeFromTimeString($data['hora_entrada']);
        $agendamientoId = $data['agendamiento_id'] ?? null;

        if (!$agendamientoId && $vehiculo) {
            $ag = Agendamiento::where('vehiculo_id', $vehiculo->vehiculo_id)
                ->whereDate('fecha', Carbon::today())
                ->orderBy('hora_inicio')
                ->first();  

            if ($ag) {
                $agendamientoId = $ag->agendamiento_id;
            }
        }
        Checkin::create([
            'vehiculo_id'      => $vehiculo?->vehiculo_id,
            'usuario_id'       => auth()->user()->usuario_id ?? null, 
            'agendamiento_id'  => $agendamientoId,
            'fotos_json'       => $fotos ? json_encode($fotos) : null,
            'ingreso_ts'       => $ingresoTs,
            'estado_recepcion' => 'PENDIENTE',
        ]);

        return redirect()
            ->route('guardia.home')
            ->with('success', 'Vehículo ingresado y solicitud enviada a recepción.');
    }

    /**
     * Registrar SALIDA del vehículo (botón "Terminar").
     * No se pide hora al guardia: se toma la hora actual del sistema.
     */
    public function finish(Request $request, $id)
    {
        $checkin = Checkin::findOrFail($id);

        if ($checkin->salida_ts !== null) {
            return back()->with('error', 'Este ingreso ya tiene hora de salida registrada.');
        }

        $checkin->salida_ts = now();
        $checkin->save();

        return back()->with('success', 'Salida del vehículo registrada correctamente.');
    }
}
