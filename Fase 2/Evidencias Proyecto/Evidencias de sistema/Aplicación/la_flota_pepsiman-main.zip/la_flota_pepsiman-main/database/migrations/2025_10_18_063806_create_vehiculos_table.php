<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('vehiculos', function (Blueprint $table) {
            $table->id('vehiculo_id');

            // Chofer actual
            $table->unsignedBigInteger('usuario_id')->nullable();

            $table->string('vehiculo_patente', 20)->unique()->collation('utf8mb4_unicode_ci');
            $table->string('vehiculo_vin', 30)->nullable()->unique();
            $table->string('vehiculo_marca', 60)->nullable();
            $table->string('vehiculo_modelo', 60)->nullable();
            $table->unsignedSmallInteger('anio')->nullable();
            $table->string('vehiculo_color', 30)->nullable();

            $table->unsignedInteger('vehiculo_kilometraje_actual')->default(0);

            $table->unsignedBigInteger('tipo_vehiculo_id');

            $table->enum('estado_vehiculo', ['activo', 'inactivo', 'baja', 'en_mantencion'])
                  ->default('activo');

            $table->string('foto', 255)->nullable();

            $table->timestamps();

            // --- FKs ---
            $table->foreign('usuario_id')
                  ->references('usuario_id')->on('usuarios')
                  ->cascadeOnUpdate()
                  ->nullOnDelete();

            $table->foreign('tipo_vehiculo_id')
                  ->references('tipo_vehiculo_id')->on('tipos_vehiculos')
                  ->cascadeOnUpdate()
                  ->restrictOnDelete();

            // --- Índices ---
            $table->index('usuario_id');
            $table->index(['vehiculo_marca', 'vehiculo_modelo'], 'vehiculos_marca_modelo_index');
            $table->index('tipo_vehiculo_id');
        });
    }

    public function down(): void {
        Schema::dropIfExists('vehiculos');
    }
};
