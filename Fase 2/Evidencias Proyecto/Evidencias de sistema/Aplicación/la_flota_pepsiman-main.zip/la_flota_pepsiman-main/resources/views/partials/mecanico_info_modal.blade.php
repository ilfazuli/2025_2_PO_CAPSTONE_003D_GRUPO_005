<dialog id="dlgInfo" class="dlg">
    <form method="dialog" class="dlg-card">
        <header class="dlg-header">
            <h3>Detalle del vehículo</h3>
        </header>

        <div class="dlg-body">
            {{-- DATOS VEHÍCULO --}}
            <section class="info-block">
                <h4>Datos del vehículo</h4>
                <div class="info-grid">
                    <p>
                        <span class="lbl">Folio OT</span>
                        <span id="infoFolio"></span>
                    </p>
                    <p>
                        <span class="lbl">Patente</span>
                        <span id="infoPatente"></span>
                    </p>
                    <p>
                        <span class="lbl">Marca</span>
                        <span id="infoMarca"></span>
                    </p>
                    <p>
                        <span class="lbl">Modelo</span>
                        <span id="infoModelo"></span>
                    </p>
                    <p>
                        <span class="lbl">Año</span>
                        <span id="infoAnio"></span>
                    </p>
                </div>
            </section>

            {{-- MOTIVO --}}
            <section class="info-block">
                <h4>Motivo de ingreso</h4>
                <p id="infoMotivo" class="info-motivo"></p>
            </section>

            {{-- COMENTARIOS --}}
            <section class="info-block">
                <h4>Comentarios del mecánico</h4>
                <ul id="infoComentarios" class="info-comentarios"></ul>
            </section>

            {{-- FOTOS --}}
            <section class="info-block">
                <h4>Fotos</h4>
                <div id="infoFotos" class="info-fotos">
                    {{-- se llena por JS --}}
                </div>
                <p class="info-fotos-hint muted">
                    Haz clic en una foto para ampliarla.
                </p>
            </section>
        </div>

        <footer class="dlg-actions">
            <button class="btn btn-primary" value="close">Cerrar</button>
        </footer>
    </form>
</dialog>

{{-- Dialog para ver la foto en grande --}}
<dialog id="dlgFotoFull" class="dlg dlg-foto-full">
    <form method="dialog" class="dlg-card">
        <header class="dlg-header">
            <h3>Foto del vehículo</h3>
        </header>
        <div class="dlg-body dlg-body-foto">
            <img id="fotoFull" src="" alt="Foto vehículo">
        </div>
        <footer class="dlg-actions">
            <button class="btn btn-primary" value="close">Cerrar</button>
        </footer>
    </form>
</dialog>
