<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        if (Auth::check()) {
            return redirect()->route('chofer.home');
        }
        return view('login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
        'email'    => ['required','email'],
        'password' => ['required','string'],
        ]);

    $remember = (bool) $request->boolean('remember');

    if (auth('web')->attempt([
        'usuario_email' => $credentials['email'],
        'password'      => $credentials['password'],
    ], $remember)) {

        $request->session()->regenerate();
        $request->session()->forget('url.intended');

        // Redirección por rol
        $user = auth('web')->user();
        return redirect()->to($this->routeForRole($user));
    }

    throw \Illuminate\Validation\ValidationException::withMessages([
        'email' => 'Credenciales inválidas.',
    ]);
}
    private function routeForRole($user)
    {
        $roles = $user->roles()->pluck('rol_code')->map(fn($c) => strtoupper($c))->toArray();

        if (in_array('ADMIN', $roles))              return route('admin.home');
        if (in_array('JEFE_TALLER', $roles))        return route('jefe.taller.panel');
        if (in_array('MECANICO', $roles))           return route('mecanico.index');
        if (in_array('RECEPCIONISTA', $roles))      return route('recep.home');
        if (in_array('GUARDIA', $roles))            return route('guardia.home');
        if (in_array('ASISTENTE_REPUESTOS', $roles))return route('asistente.repuestos.home');
        if (in_array('SUPERVISOR', $roles))         return route('supervisor.home');
        if (in_array('COORDINADOR_ZONA', $roles))   return route('coordinador.home');
        if (in_array('ENCARGADO_LLAVES', $roles))   return route('encargado.home');
        if (in_array('CHOFER', $roles))             return route('chofer.home');

        
        return route('chofer.home');
    }


    public function logout(Request $request)
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
