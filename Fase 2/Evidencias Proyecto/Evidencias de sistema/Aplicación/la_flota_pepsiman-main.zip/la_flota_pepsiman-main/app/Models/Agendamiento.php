<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Agendamiento extends Model
{
    protected $table = 'agendamientos';
    protected $primaryKey = 'agendamiento_id';
    protected $fillable = [
      'vehiculo_id','usuario_id','tipo_servicio_id',
      'fecha','hora_inicio','hora_fin','estado','canal'
    ];

    public const ESTADOS_BLOQUEO = ['PENDIENTE','CONFIRMADO','EN_ATENCION'];

    public function vehiculo(){ return $this->belongsTo(Vehiculo::class,'vehiculo_id','vehiculo_id'); }
    public function usuario(){ return $this->belongsTo(Usuario::class,'usuario_id','usuario_id'); }
    public function tipoServicio(){ return $this->belongsTo(TipoServicio::class, 'tipo_servicio_id', 'ts_id'); }
}
