<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrdenTrabajoFoto extends Model
{
    protected $table = 'orden_trabajo_fotos';

    protected $fillable = [
        'orden_trabajo_id',
        'vehiculo_id',
        'mecanico_id',
        'tipo',
        'path',
        'nota',
    ];

    public function ordenTrabajo()
    {
        return $this->belongsTo(OrdenTrabajo::class, 'orden_trabajo_id');
    }

    public function vehiculo()
    {
        return $this->belongsTo(Vehiculo::class, 'vehiculo_id', 'vehiculo_id');
    }

    public function mecanico()
    {
        return $this->belongsTo(Usuario::class, 'mecanico_id', 'usuario_id');
    }
}
