<?php

namespace App\Http\Controllers\Chofer;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Vehiculo;
use App\Models\Documento;

class DocumentacionController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Vehículos asignados directamente al chofer
        $vehiculos = Vehiculo::where('usuario_id', $user->usuario_id)->get();

        if ($vehiculos->isEmpty()) {
            // Chofer sin vehículo asignado
            return view('vista_chofer_documentacion', [
                'vehiculo'   => null,
                'docsPorTipo'=> [],
            ]);
        }

        // Por ahora tomamos el primer vehículo asignado
        $vehiculo = $vehiculos->first();

        $docs = Documento::where('vehiculo_id', $vehiculo->vehiculo_id)
            ->orderByDesc('fecha_emision')
            ->get();

        // Slots fijos que espera la Blade
        $porTipo = [
            'soap'               => null,
            'revision_tecnica'   => null,
            'permiso_circulacion'=> null,
            'padron'             => null,
            'gases'              => null,
            'otros'              => null,
        ];

        foreach ($docs as $d) {
            // Tomamos el tipo tal como está en BD
            $tipoRaw = strtoupper($d->tipo ?? '');
            $clave = null;

            switch ($tipoRaw) {
                // Seguro obligatorio / SOAP
                case 'SEGURO_OBLIGATORIO':
                case 'SOAP':
                    $clave = 'soap';
                    break;

                // Revisión técnica
                case 'REVISION_TECNICA':
                    $clave = 'revision_tecnica';
                    break;

                // Permiso de circulación
                case 'PERMISO_CIRCULACION':
                    $clave = 'permiso_circulacion';
                    break;

                // Padrón
                case 'PADRON':
                    $clave = 'padron';
                    break;

                // Gases
                case 'GASES':
                case 'CERT_GASES':
                    $clave = 'gases';
                    break;

                // Otros documentos
                case 'OTRO':
                case 'OTROS':
                    $clave = 'otros';
                    break;

                default:
                    // Si agregamos nuevos tipos en el futuro, caen aquí
                    break;
            }

            // Guardamos solo el primero que encontremos de cada tipo
            if ($clave && $porTipo[$clave] === null) {
                $porTipo[$clave] = $d;
            }
        }

        return view('vista_chofer_documentacion', [
            'vehiculo'   => $vehiculo,
            'docsPorTipo'=> $porTipo,
        ]);
    }
}
