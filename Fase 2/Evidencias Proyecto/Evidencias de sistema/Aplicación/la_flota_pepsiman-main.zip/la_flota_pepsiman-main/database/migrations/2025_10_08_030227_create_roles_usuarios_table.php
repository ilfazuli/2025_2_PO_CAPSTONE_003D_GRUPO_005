<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration {
    public function up(): void {
        Schema::create('roles_usuarios', function (Blueprint $table) {
            $table->id('rol_usuario_id');
            $table->unsignedBigInteger('usuario_id');
            $table->unsignedBigInteger('rol_id');
            $table->timestamps();

            $table->unique(['usuario_id', 'rol_id']);

            $table->foreign('usuario_id')
                  ->references('usuario_id')->on('usuarios')
                  ->onUpdate('restrict')->onDelete('restrict');

            $table->foreign('rol_id')
                  ->references('rol_id')->on('roles')
                  ->onUpdate('restrict')->onDelete('restrict');
        });
    }
    public function down(): void {
        Schema::dropIfExists('roles_usuarios');
    }
};