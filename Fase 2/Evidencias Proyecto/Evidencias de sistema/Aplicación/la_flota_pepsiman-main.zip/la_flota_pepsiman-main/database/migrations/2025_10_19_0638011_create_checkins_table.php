<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('checkins', function (Blueprint $table) {
            $table->bigIncrements('checkin_id');

            // --- Relaciones ---
            $table->unsignedBigInteger('vehiculo_id')->nullable();
            $table->unsignedBigInteger('usuario_id')->nullable(); // Guardia que registra
            $table->unsignedBigInteger('agendamiento_id')->nullable(); // Si vino con reserva

            // --- Datos del ingreso ---
            $table->json('fotos_json')->nullable();
            $table->timestamp('ingreso_ts')->nullable();  // Hora de entrada
            $table->timestamp('salida_ts')->nullable();   // Hora de salida
            $table->string('estado_recepcion', 20)->default('PENDIENTE');

            $table->timestamps();

            // --- Índices ---
            $table->index('vehiculo_id');
            $table->index('usuario_id');
            $table->index('agendamiento_id');
            $table->index('ingreso_ts');
            $table->index('salida_ts');

            // --- Foreign keys ---
            $table->foreign('vehiculo_id')
                ->references('vehiculo_id')->on('vehiculos')
                ->nullOnDelete()->cascadeOnUpdate();

            $table->foreign('usuario_id')
                ->references('usuario_id')->on('usuarios')
                ->nullOnDelete()->cascadeOnUpdate();

            $table->foreign('agendamiento_id')
                ->references('agendamiento_id')->on('agendamientos')
                ->nullOnDelete()->cascadeOnUpdate();
        });
    }

    public function down(): void {
        Schema::dropIfExists('checkins');
    }
};