<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('orden_trabajo_fotos', function (Blueprint $t) {
            $t->id();

            // Relación principal
            $t->unsignedBigInteger('orden_trabajo_id');
            $t->unsignedBigInteger('vehiculo_id')->nullable();

            // Quién subió la foto 
            $t->unsignedBigInteger('mecanico_id')->nullable();

            // Clasificación simple de la foto
            $t->string('tipo', 30)->default('PROCESO');

            // Ruta en storage
            $t->string('path', 255);

            // Comentario breve de la foto
            $t->text('nota')->nullable();

            $t->timestamps();

            // FKs
            $t->foreign('orden_trabajo_id')
                ->references('id')->on('ordenes_trabajos')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();

            $t->foreign('vehiculo_id')
                ->references('vehiculo_id')->on('vehiculos')
                ->cascadeOnUpdate()
                ->nullOnDelete();

            $t->foreign('mecanico_id')
                ->references('usuario_id')->on('usuarios')
                ->cascadeOnUpdate()
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orden_trabajo_fotos');
    }
};
