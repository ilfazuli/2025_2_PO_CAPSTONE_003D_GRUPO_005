<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class RoleMiddleware
{
    public function handle($request, Closure $next, ...$roles)
    {
        $user = Auth::user();
        if (!$user) abort(401);

        $codes = $user->roles()->pluck('rol_code')
          ->map(fn($c) => Str::upper(Str::ascii($c)))
          ->toArray();

        if (in_array('ADMIN', $codes, true)) return $next($request);

        $required = array_map(fn($r) => Str::upper(Str::ascii($r)), $roles);
        foreach ($required as $r) if (in_array($r, $codes, true)) return $next($request);
        abort(403);
    }
}