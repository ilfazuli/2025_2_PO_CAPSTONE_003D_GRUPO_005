<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $rows = [
            ['rol_code'=>'ADMIN',              'rol_nombre'=>'Administrador',          'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'RECEPCIONISTA',      'rol_nombre'=>'Recepcionista',          'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'CHOFER',             'rol_nombre'=>'Chofer',                 'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'GUARDIA',            'rol_nombre'=>'Guardia',                'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'MECANICO',           'rol_nombre'=>'Mecánico',               'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'JEFE_TALLER',        'rol_nombre'=>'Jefe de taller',         'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'ASISTENTE_REPUESTOS','rol_nombre'=>'Asistente de repuestos', 'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'SUPERVISOR',         'rol_nombre'=>'Supervisor',             'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'COORDINADOR_ZONA',   'rol_nombre'=>'Coordinador de zona',    'created_at'=>$now,'updated_at'=>$now],
            ['rol_code'=>'ENCARGADO_LLAVES',   'rol_nombre'=>'Encargado de llaves',    'created_at'=>$now,'updated_at'=>$now],
        ];
        DB::table('roles')->upsert($rows, ['rol_code'], ['rol_nombre','updated_at']);
    }
}
