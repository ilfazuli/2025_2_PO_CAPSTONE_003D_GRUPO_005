<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;

use App\Models\Vehiculo;
use App\Models\TipoVehiculo;
use App\Models\Usuario;
use App\Models\VehiculoChofer;

class VehiculoAdminController extends Controller
{
    public function index(Request $request)
    {
        $q        = trim((string) $request->get('q', '')); // patente
        $marca    = trim((string) $request->get('marca', ''));
        $modelo   = trim((string) $request->get('modelo', ''));
        $tipoId   = $request->get('tipo_vehiculo_id');
        $estado   = $request->get('estado');
        $choferId = $request->get('chofer_id');

        $vehiculos = Vehiculo::with(['tipo', 'chofer'])
            ->when($q !== '', fn($qb) => $qb->where('vehiculo_patente', 'LIKE', "%{$q}%"))
            ->when($marca !== '', fn($qb) => $qb->where('vehiculo_marca', $marca))
            ->when($modelo !== '', fn($qb) => $qb->where('vehiculo_modelo', $modelo))
            ->when($tipoId, fn($qb) => $qb->where('tipo_vehiculo_id', $tipoId))
            ->when(in_array($estado, ['activo','inactivo','baja','en_mantencion'], true),
                fn($qb) => $qb->where('estado_vehiculo', $estado))
            ->when($choferId, fn($qb) => $qb->where('usuario_id', $choferId))
            ->orderByDesc('vehiculo_id')
            ->get();

        // listas para filtros
        $marcas   = Vehiculo::whereNotNull('vehiculo_marca')->distinct()->orderBy('vehiculo_marca')->pluck('vehiculo_marca');
        $modelos  = Vehiculo::whereNotNull('vehiculo_modelo')->distinct()->orderBy('vehiculo_modelo')->pluck('vehiculo_modelo');
        $tipos    = TipoVehiculo::where('activo', 1)->orderBy('tipo_nombre')->get();
        $choferes = Usuario::whereHas('roles', fn($q) => $q->where('rol_nombre', 'Chofer'))
                        ->orderBy('usuario_nombre')->get();

        return view('vista_admin_vehiculo', compact(
            'vehiculos','tipos','choferes','marcas','modelos','q','marca','modelo','tipoId','estado','choferId'
        ));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'vehiculo_patente'            => 'required|string|max:20|unique:vehiculos,vehiculo_patente',
            'vehiculo_marca'              => 'nullable|string|max:60',
            'vehiculo_modelo'             => 'nullable|string|max:60',
            'anio'                        => 'nullable|integer|min:1900|max:2100',
            'vehiculo_kilometraje_actual' => 'nullable|integer|min:0',
            'tipo_vehiculo_id' => [
                'required',
                Rule::exists('tipos_vehiculos', 'tipo_vehiculo_id')->where(fn($q) => $q->where('activo', 1)),
            ],
            'estado_vehiculo'             => 'required|in:activo,inactivo,baja,en_mantencion',
        ]);

        $vehiculo = Vehiculo::create($validated);

        if ($request->expectsJson()) {
            return response()->json(['success' => true, 'vehiculo_id' => $vehiculo->vehiculo_id]);
        }

        return redirect()->route('admin.vehiculos.index')->with('success', 'Vehículo creado correctamente.');
    }

    public function update(Request $request, $id)
    {
        $vehiculo = Vehiculo::findOrFail($id);

        $validated = $request->validate([
            'vehiculo_patente' => [
                'required','string','max:20',
                Rule::unique('vehiculos', 'vehiculo_patente')->ignore($vehiculo->vehiculo_id, 'vehiculo_id'),
            ],
            'vehiculo_marca'              => 'nullable|string|max:60',
            'vehiculo_modelo'             => 'nullable|string|max:60',
            'anio'                        => 'nullable|integer|min:1900|max:2100',
            'vehiculo_kilometraje_actual' => 'nullable|integer|min:0',
            'tipo_vehiculo_id' => [
                'required',
                Rule::exists('tipos_vehiculos', 'tipo_vehiculo_id')->where(fn($q) => $q->where('activo', 1)),
            ],
            'estado_vehiculo'             => 'required|in:activo,inactivo,baja,en_mantencion',
        ]);

        $vehiculo->update($validated);

        if ($request->expectsJson()) {
            return response()->json(['success' => true]);
        }

        return redirect()->route('admin.vehiculos.index')->with('success', 'Vehículo actualizado.');
    }

    public function destroy(Request $request, $id)
    {
        $vehiculo = Vehiculo::findOrFail($id);

        DB::beginTransaction();
        try {
            // Cerrar asignación activa
            VehiculoChofer::where('vehiculo_id', $vehiculo->vehiculo_id)
                ->whereNull('hasta_ts')
                ->update([
                    'hasta_ts' => now(),
                    'motivo'   => 'Cierre por baja de vehículo',
                ]);

            // Dejar sin chofer y marcar baja
            $vehiculo->update([
                'usuario_id'      => null,
                'estado_vehiculo' => 'baja',
            ]);

            DB::commit();

            if ($request->expectsJson()) {
                return response()->json(['success' => true]);
            }

            return redirect()
                ->route('admin.vehiculos.index')
                ->with('success', 'Vehículo dado de baja y asignaciones cerradas.');
        } catch (\Throwable $e) {
            DB::rollBack();

            if ($request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Error al dar de baja'], 500);
            }

            return back()->with('error', 'No se pudo dar de baja el vehículo: ' . $e->getMessage());
        }
    }
}
