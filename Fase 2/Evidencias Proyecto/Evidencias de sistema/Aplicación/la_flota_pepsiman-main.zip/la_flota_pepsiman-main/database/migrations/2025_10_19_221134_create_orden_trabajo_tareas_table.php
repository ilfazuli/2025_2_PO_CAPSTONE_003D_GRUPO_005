<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('orden_trabajo_tareas', function (Blueprint $t) {

            $t->id();

            // Relación con la OT
            $t->unsignedBigInteger('orden_trabajo_id');
            $t->foreign('orden_trabajo_id')
                ->references('id')->on('ordenes_trabajos')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();

            //  relación a tipo_servicios
            $t->unsignedBigInteger('tipo_servicio_id');
            $t->foreign('tipo_servicio_id')
                ->references('ts_id')->on('tipo_servicios')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();

            // Mecanico asignado a esa tarea
            $t->unsignedBigInteger('mecanico_id')->nullable();
            $t->foreign('mecanico_id')
                ->references('usuario_id')->on('usuarios')
                ->nullOnDelete();

            // Tiempo y estados
            $t->timestamp('inicio_ts')->nullable();
            $t->timestamp('fin_ts')->nullable();

            $t->string('estado', 20)
                ->default('pendiente'); 
                // pendiente | en_proceso | pausada | finalizada | rechazada

            // Comentarios del mecánico
            $t->text('nota')->nullable();

            $t->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orden_trabajo_tareas');
    }
};
