<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('notificaciones', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('usuario_id_receptor')->nullable();
            $t->foreign('usuario_id_receptor')->references('usuario_id')->on('usuarios')->cascadeOnDelete();
            $t->string('codigo_plantilla');
            $t->string('estado')->default('pendiente'); 
            $t->string('related_entity')->nullable();   
            $t->unsignedBigInteger('related_id')->nullable();
            $t->json('datos')->nullable();
            $t->timestamp('enviada_ts')->nullable();
            $t->timestamp('leida_ts')->nullable();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('notificaciones'); }
};
