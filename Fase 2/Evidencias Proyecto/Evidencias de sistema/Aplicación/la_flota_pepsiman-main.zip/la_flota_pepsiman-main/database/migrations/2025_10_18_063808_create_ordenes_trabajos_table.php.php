<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('ordenes_trabajos', function (Blueprint $table) {
            $table->id();

            // Folio
            $table->string('folio', 40)->unique();

            // Relaciones
            $table->unsignedBigInteger('vehiculo_id');
            $table->unsignedBigInteger('agendamiento_id')->nullable();
            $table->unsignedBigInteger('mecanico_id')->nullable();

            // Estado y trazas
            $table->string('estado', 20)->default('ABIERTA');
            $table->string('estado_mecanico', 20)->default('PENDIENTE');
            $table->timestamp('apertura_ts')->useCurrent();
            $table->timestamp('cierre_ts')->nullable();
            $table->integer('tiempo_trabajo_min')->nullable();

            $table->unsignedTinyInteger('prioridad')->default(3);
            $table->string('origen', 20)->default('AGENDA');

            $table->timestamps();

            // Índices
            $table->index(['vehiculo_id', 'estado']);
            $table->index('agendamiento_id');
            $table->index('mecanico_id');

            // FK
            $table->foreign('vehiculo_id')
                ->references('vehiculo_id')->on('vehiculos')
                ->cascadeOnUpdate()
                ->restrictOnDelete();

            $table->foreign('agendamiento_id')
                ->references('agendamiento_id')->on('agendamientos')
                ->cascadeOnUpdate()
                ->nullOnDelete();
                
            $table->foreign('mecanico_id')
                ->references('usuario_id')->on('usuarios')
                ->cascadeOnUpdate()
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ordenes_trabajos');
    }
};
