<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('vehiculos_choferes', function (Blueprint $table) {
            $table->bigIncrements('vehiculo_chofer_id');

            $table->unsignedBigInteger('vehiculo_id');
            $table->unsignedBigInteger('usuario_id')->nullable(); 
            $table->string('usuario_nombre_snapshot', 255)->nullable();

            // periodo de la asignación
            $table->timestamp('desde_ts')->useCurrent();
            $table->timestamp('hasta_ts')->nullable(); 

            $table->string('motivo', 100)->nullable();
            $table->timestamps();

            // índices útiles
            $table->index(['vehiculo_id', 'hasta_ts']);
            $table->index(['usuario_id', 'hasta_ts']);

            // FKs
            $table->foreign('vehiculo_id')
                  ->references('vehiculo_id')->on('vehiculos')
                  ->cascadeOnUpdate()
                  ->restrictOnDelete();

            $table->foreign('usuario_id')
                  ->references('usuario_id')->on('usuarios')
                  ->cascadeOnUpdate()
                  ->nullOnDelete(); 
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehiculos_choferes');
    }
};
