<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tipo_servicios', function (Blueprint $table) {
            $table->bigIncrements('ts_id');
            $table->string('ts_code', 50)->unique();      
            $table->string('ts_nombre', 120);              
            $table->string('ts_descripcion', 255)->nullable();
            $table->unsignedSmallInteger('duracion_minutos')->default(60); 
            $table->boolean('ts_activo')->default(true);
            $table->timestamps();

            $table->index(['ts_activo']);
        });
    }

    public function down(): void {
        Schema::dropIfExists('tipo_servicios');
    }
};
