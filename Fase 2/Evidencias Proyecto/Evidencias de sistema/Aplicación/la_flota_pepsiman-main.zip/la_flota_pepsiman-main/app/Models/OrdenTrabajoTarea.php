<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrdenTrabajoTarea extends Model
{
    protected $table = 'orden_trabajo_tareas';

    protected $fillable = [
        'orden_trabajo_id',
        'tipo_servicio_id',
        'mecanico_id',
        'inicio_ts',
        'fin_ts',
        'estado',
        'nota',
    ];

    protected $casts = [
        'inicio_ts' => 'datetime',
        'fin_ts'    => 'datetime',
    ];

    public function ordenTrabajo()
    {
        return $this->belongsTo(OrdenTrabajo::class, 'orden_trabajo_id');
    }

    public function tipoServicio()
    {
        return $this->belongsTo(TipoServicio::class, 'tipo_servicio_id', 'ts_id');
    }

    public function mecanico()
    {
        return $this->belongsTo(Usuario::class, 'mecanico_id', 'usuario_id');
    }
}
