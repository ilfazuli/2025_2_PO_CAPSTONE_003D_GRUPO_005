<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoVehiculo extends Model
{
    protected $table = 'tipos_vehiculos';
    protected $primaryKey = 'tipo_vehiculo_id';
    protected $fillable = ['tipo_code','tipo_nombre','activo'];

    public function vehiculos()
    {
        return $this->hasMany(Vehiculo::class, 'tipo_vehiculo_id', 'tipo_vehiculo_id');
    }
}

