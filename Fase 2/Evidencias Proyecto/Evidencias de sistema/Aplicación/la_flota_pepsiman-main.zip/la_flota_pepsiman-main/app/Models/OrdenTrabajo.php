<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo; 
use App\Models\Usuario;                              

class OrdenTrabajo extends Model
{
    use HasFactory;

    protected $table = 'ordenes_trabajos';
    protected $primaryKey = 'id';
    public $timestamps = true;

    protected $fillable = [
        'folio',
        'vehiculo_id',
        'agendamiento_id',
        'mecanico_id',
        'estado',
        'apertura_ts',
        'cierre_ts',
        'prioridad',
        'origen',
    ];

    protected $casts = [
        'apertura_ts' => 'datetime',
        'cierre_ts'   => 'datetime',
    ];

    // Relación con Vehiculo
    public function vehiculo(): BelongsTo
    {
        return $this->belongsTo(Vehiculo::class, 'vehiculo_id', 'vehiculo_id');
    }

    // Relación con Agendamiento
    public function agendamiento(): BelongsTo
    {
        return $this->belongsTo(Agendamiento::class, 'agendamiento_id', 'agendamiento_id');
    }

    // Relación con mecánico
    public function mecanico(): BelongsTo
    {
        return $this->belongsTo(Usuario::class, 'mecanico_id', 'usuario_id');
    }
}
