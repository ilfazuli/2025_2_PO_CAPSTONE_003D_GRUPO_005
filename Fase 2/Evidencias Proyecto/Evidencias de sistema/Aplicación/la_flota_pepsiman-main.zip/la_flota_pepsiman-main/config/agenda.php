<?php
return [
    'open'  => env('AGENDA_OPEN',  '08:00'),
    'close' => env('AGENDA_CLOSE', '18:00'),
    'step'  => (int) env('AGENDA_STEP', 30),

    'blocking_status' => ['PENDIENTE', 'CONFIRMADO'],

    'default_channel'   => env('AGENDA_CHANNEL', 'WEB_CHOFER'),
];