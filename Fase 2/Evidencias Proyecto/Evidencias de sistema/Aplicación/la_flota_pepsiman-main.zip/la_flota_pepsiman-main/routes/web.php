<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Admin\UserAdminController;
use App\Http\Controllers\Auth\ChoferRegisterController;
use App\Http\Controllers\Chofer\ReservaController;
use App\Http\Controllers\Admin\VehiculoAdminController;
use App\Http\Controllers\GuardiaController;
use App\Http\Controllers\RecepcionistaController;
use App\Http\Controllers\JefeTallerController;
use App\Http\Controllers\MecanicoController;
use App\Http\Controllers\Admin\DocumentoVehiculoController;
use App\Http\Controllers\Chofer\DocumentacionController;
use App\Http\Controllers\Admin\OtAdminController;

Route::get('/', function () {
    return view('login');
});

// LOGIN / LOGOUT

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');

    Route::post('/login', [LoginController::class, 'login'])
        ->middleware('throttle:6,1') 
        ->name('login.attempt');

    Route::get('/password/forgot', [PasswordResetLinkController::class, 'create'])
        ->name('password.request');

    Route::post('/password/forgot', [PasswordResetLinkController::class, 'store'])
        ->name('password.email');

    Route::get('/password/reset/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset');

    Route::post('/password/reset', [NewPasswordController::class, 'store'])
        ->name('password.update');

    Route::get('/registro/chofer', [ChoferRegisterController::class, 'create'])
        ->name('chofer.registro.show');

    Route::post('/registro/chofer', [ChoferRegisterController::class, 'store'])
        ->name('chofer.registro.store');


});
Route::post('/logout', [LoginController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');
    
// ===========================================================


// RUTAS PROTEGIDAS 

// SOLO ADMIN
Route::middleware(['auth','role:ADMIN'])->group(function () {

    // === HOME ADMIN ===
    Route::view('/administrador', 'administrador')->name('admin.home');

    // === GESTIÓN DE USUARIOS ===
    Route::prefix('/administrador/usuarios')->name('admin.usuarios.')->group(function () {
        Route::get ('/',        [UserAdminController::class, 'index'])->name('index');
        Route::post('/',        [UserAdminController::class, 'store'])->name('store');
        Route::put('/{id}/password', [UserAdminController::class, 'resetPassword'])->whereNumber('id')->name('reset');
        Route::get ('/{id}',    [UserAdminController::class, 'show'])->whereNumber('id')->name('show');
        Route::put ('/{id}',    [UserAdminController::class, 'update'])->whereNumber('id')->name('update');
        Route::put ('/{id}/estado',     [UserAdminController::class, 'toggleState'])->whereNumber('id')->name('toggle');
        Route::delete ('/{id}', [UserAdminController::class, 'destroy'])->whereNumber('id')->name('destroy');
    });
    Route::post('/administrador/asignar-chofer', [UserAdminController::class, 'asignarChofer'])->name('admin.asignarChofer');

        // === ADMIN VEHICULOS ===
    Route::prefix('/administrador/vehiculos')->name('admin.vehiculos.')->group(function () {
        Route::get('/', [VehiculoAdminController::class, 'index'])->name('index');
        Route::post('/', [VehiculoAdminController::class, 'store'])->name('store');
        Route::put('/{id}', [VehiculoAdminController::class, 'update'])->name('update'); 
        Route::delete('/{id}', [VehiculoAdminController::class, 'destroy'])->name('destroy');
        // Documentación de vehículos (AJAX)
        Route::get('/{vehiculo}/documentos', [DocumentoVehiculoController::class, 'index'])
            ->whereNumber('vehiculo')
            ->name('documentos.index');

        Route::post('/{vehiculo}/documentos', [DocumentoVehiculoController::class, 'store'])
            ->whereNumber('vehiculo')
            ->name('documentos.store');
    });

    // Rutas para editar / eliminar documento
    Route::prefix('/administrador/documentos')->name('admin.documentos.')->group(function () {
        Route::put('/{id}',    [DocumentoVehiculoController::class, 'update'])->whereNumber('id')->name('update');
        Route::delete('/{id}', [DocumentoVehiculoController::class, 'destroy'])->whereNumber('id')->name('destroy');
    });

    // === VISUALIZACIÓN DE OT ===
    Route::prefix('/administrador/ots')->name('admin.ots.')->group(function () {
        // Vista con listado / métricas de OT
        Route::get('/', [OtAdminController::class, 'index'])->name('index');

        // Exportar todas las OT a CSV (para abrir en Excel)
        Route::get('/export', [OtAdminController::class, 'exportCsv'])->name('export');
    });


});


// CHOFER
Route::middleware(['auth','role:CHOFER'])->group(function () {
        Route::get('/chofer', fn() => view('vista_chofer'))->name('chofer.home');

        // Mostrar la pantalla de reservar hora
        Route::get('/chofer/reservar-hora', [ReservaController::class, 'index'])
            ->name('chofer.reserva');

        // API para traer slots disponibles (AJAX)
        Route::get('/chofer/reservar-hora/slots', [ReservaController::class, 'slots'])
            ->name('chofer.reserva.slots');

        // Guardar la reserva
        Route::post('/chofer/reservar-hora', [ReservaController::class, 'store'])
            ->name('chofer.reserva.store');
            
        // Ver documentacion    
        Route::get('/chofer/ver-documentacion', [DocumentacionController::class, 'index'])->name('chofer.docs');           
    });
    
// RECEPCIONISTA
Route::middleware(['auth','role:RECEPCIONISTA'])->group(function () {
    // Vista principal de recepción
    Route::get('/recepcionista', [RecepcionistaController::class, 'index'])
        ->name('recep.home');

    // Aceptar solicitud (crea OT)
    Route::post('/recepcionista/solicitud/{id}/aceptar', [RecepcionistaController::class, 'aceptar'])
        ->whereNumber('id')
        ->name('recep.solicitud.aceptar');

    // Rechazar solicitud
    Route::post('/recepcionista/solicitud/{id}/rechazar', [RecepcionistaController::class, 'rechazar'])
        ->whereNumber('id')
        ->name('recep.solicitud.rechazar');
});


// GUARDIA
Route::middleware(['auth','role:GUARDIA'])->group(function () {
    // Listado de vehículos en el taller (vista principal del guardia)
    Route::get('/guardia', [GuardiaController::class, 'index'])->name('guardia.home');

    // Registrar INGRESO (cuando el guardia agrega vehículo en el modal)
    Route::post('/guardia/checkin', [GuardiaController::class, 'store'])->name('guardia.checkin.store');

    // Registrar SALIDA (cuando el guardia pulsa "Terminar" y envía la hora de salida)
    Route::put('/guardia/checkin/{id}/finish', [GuardiaController::class, 'finish'])->whereNumber('id')->name('guardia.checkin.finish');
});
// ===========================================================

// MECANICO

Route::middleware(['auth','role:MECANICO'])->group(function () {
    Route::get('/mecanico', [MecanicoController::class, 'index'])->name('mecanico.index');
    Route::get('/mecanico/historial_ot', [MecanicoController::class, 'historial'])->name('mecanico.historial');

    Route::post('/mecanico/ot/{ot}/iniciar',    [MecanicoController::class, 'iniciarTrabajo']);
    Route::post('/mecanico/ot/{ot}/pausar',     [MecanicoController::class, 'pausarTrabajo']);
    Route::post('/mecanico/ot/{ot}/finalizar',  [MecanicoController::class, 'finalizarTrabajo']);
    Route::post('/mecanico/ot/{ot}/comentario', [MecanicoController::class, 'guardarComentario']);
    Route::get ('/mecanico/ot/{ot}/info',       [MecanicoController::class, 'info']);
    Route::post('/mecanico/ot/{ot}/foto',       [MecanicoController::class, 'subirFoto']);
});


// ===========================================================

// JEFE DE TALLER
Route::middleware(['auth','role:JEFE_TALLER'])->group(function () {
    Route::get('/jefe-taller', [JefeTallerController::class, 'index'])
        ->name('jefe.taller.panel');

    Route::get('/jefe-taller/data', [JefeTallerController::class, 'data'])
        ->name('jefe.taller.data');

    Route::post('/jefe-taller/ot/{ot}/cerrar', [JefeTallerController::class, 'cerrar'])
        ->name('jefe.taller.cerrar');

    Route::post('/jefe-taller/ot/{ot}/asignar-mecanico', [JefeTallerController::class, 'asignarMecanico'])
        ->name('jefe.taller.asignar');
});
// ===========================================================