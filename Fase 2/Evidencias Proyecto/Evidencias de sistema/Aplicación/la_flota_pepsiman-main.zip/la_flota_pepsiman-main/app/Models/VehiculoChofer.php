<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Usuario; 

class VehiculoChofer extends Model
{
    use HasFactory;

    protected $table = 'vehiculos_choferes';
    protected $primaryKey = 'vehiculo_chofer_id';
    public $timestamps = true;

    protected $fillable = [
        'vehiculo_id',
        'usuario_id',
        'usuario_nombre_snapshot',
        'desde_ts',
        'hasta_ts',
        'motivo',
    ];

    public function vehiculo()
    {
        return $this->belongsTo(Vehiculo::class, 'vehiculo_id', 'vehiculo_id');
    }

    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id', 'usuario_id');
    }

    protected static function booted()
    {
        static::saving(function ($registro) {
            if ($registro->usuario_id && empty($registro->usuario_nombre_snapshot)) {
                $usuario = Usuario::find($registro->usuario_id);
                if ($usuario) {
                    $registro->usuario_nombre_snapshot = $usuario->usuario_nombre;
                }
            }
        });
    }
}
