<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TipoServiciosSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $rows = [
            ['ts_code' => 'REV_TEC',   'ts_nombre' => 'Revisión Técnica',      'duracion_minutos' => 90, 'ts_activo' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['ts_code' => 'PREVENTIVO','ts_nombre' => 'Mantención Preventiva', 'duracion_minutos' => 60, 'ts_activo' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['ts_code' => 'REPARACION','ts_nombre' => 'Reparación',             'duracion_minutos' => 120,'ts_activo' => 1, 'created_at' => $now, 'updated_at' => $now],
        ];

        DB::table('tipo_servicios')->upsert($rows, ['ts_code'], ['ts_nombre','duracion_minutos','ts_activo','updated_at']);
    }
}
