<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('calidad_checks', function (Blueprint $t) {
            $t->id();
            $t->string('checklist_codigo'); 
            $t->string('resultado');        // aprobado|rechazado|observado
            $t->text('observaciones')->nullable();
            $t->foreignId('orden_trabajo_tarea_id')->constrained('orden_trabajo_tareas')->cascadeOnDelete();
            $t->unsignedBigInteger('inspector_id')->nullable();
            $t->foreign('inspector_id')->references('usuario_id')->on('usuarios')->nullOnDelete();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('calidad_checks'); }
};
