<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TipoVehiculosSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $rows = [
            ['tipo_code'=>'AUTO',      'tipo_nombre'=>'Auto',       'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'CAMION',    'tipo_nombre'=>'Camión',     'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'CAMIONETA', 'tipo_nombre'=>'Camioneta',  'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'SUV',       'tipo_nombre'=>'SUV',        'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'VAN',       'tipo_nombre'=>'Van',        'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'MOTO',      'tipo_nombre'=>'Moto',       'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
            ['tipo_code'=>'OTRO',      'tipo_nombre'=>'Otro',       'activo'=>1, 'created_at'=>$now, 'updated_at'=>$now],
        ];

        DB::table('tipos_vehiculos')->upsert(
            $rows,
            ['tipo_code'],
            ['tipo_nombre','activo','updated_at']
        );
    }
}

