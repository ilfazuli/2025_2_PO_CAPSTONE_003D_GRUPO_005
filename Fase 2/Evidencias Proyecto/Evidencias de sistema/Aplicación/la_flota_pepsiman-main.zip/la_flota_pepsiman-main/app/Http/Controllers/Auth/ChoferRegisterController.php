<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class ChoferRegisterController extends Controller
{
    public function create()
    {
        return view('auth.chofer_registro');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nombre'                 => ['required','string','min:3','max:120'],
            'email'                  => ['required','email','max:180','unique:usuarios,usuario_email'],
            'telefono'               => ['required','string','min:9','max:30'],
            'password'               => [
                'required','string','min:8',
                'regex:/[A-ZÁÉÍÓÚÑ]/', 'regex:/[a-záéíóúñ]/', 'regex:/\d/', 'regex:/[!@#$%^&*()\[\]{}\-_+=~`|:;"\'<>,.?\/\\\\]/'
            ],
            'password_confirmation'  => ['required','same:password'],
            'terms'                  => ['accepted'],
        ], [
            'password.regex' => 'La contraseña debe tener mayúscula, minúscula, número y símbolo.',
        ]);

        $usuario = Usuario::create([
            'usuario_nombre'    => $data['nombre'],
            'usuario_email'     => strtolower($data['email']),
            'usuario_telefono'  => $data['telefono'],
            'usuario_password'  => Hash::make($data['password']), 
        ]);

        $rolChoferId = DB::table('roles')->where('rol_code', 'chofer')->value('rol_id');
        if ($rolChoferId) {
            DB::table('roles_usuarios')->insert([
                'usuario_id' => $usuario->getKey(),
                'rol_id'     => $rolChoferId,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return redirect()->route('login')->with('status', 'Cuenta creada. Ahora inicia sesión.');
    }
}
