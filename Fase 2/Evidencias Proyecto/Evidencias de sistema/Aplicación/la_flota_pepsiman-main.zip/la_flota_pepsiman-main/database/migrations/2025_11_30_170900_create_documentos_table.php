<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('documentos', function (Blueprint $table) {
            $table->bigIncrements('id');

            // Relación con vehículo
            $table->unsignedBigInteger('vehiculo_id');

            // Tipo de documento (permiso, revisión, SOAP, padrón, etc.)
            $table->string('tipo', 50);

            // Texto opcional
            $table->string('descripcion', 255)->nullable();

            // Ruta del archivo en el storage (storage/app/public/...)
            $table->string('archivo_path', 255);

            // Fechas opcionales
            $table->date('fecha_emision')->nullable();
            $table->date('fecha_vencimiento')->nullable();

            $table->timestamps();

            // Foreign key a vehiculos
            $table->foreign('vehiculo_id')
                ->references('vehiculo_id')->on('vehiculos')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('documentos');
    }
};
