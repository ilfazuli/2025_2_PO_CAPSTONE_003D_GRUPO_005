<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vehiculo extends Model
{
    protected $table = 'vehiculos';
    protected $primaryKey = 'vehiculo_id';

    protected $fillable = [
        'usuario_id',
        'vehiculo_patente',
        'vehiculo_vin',
        'vehiculo_marca',
        'vehiculo_modelo',
        'anio',
        'vehiculo_color',
        'vehiculo_kilometraje_actual',
        'tipo_vehiculo_id',
        'estado_vehiculo',
        'foto',
    ];
    public function tipo()
    {
        return $this->belongsTo(TipoVehiculo::class, 'tipo_vehiculo_id', 'tipo_vehiculo_id');
    }

    public function chofer()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id', 'usuario_id');
    }

    public function asignaciones()
    {
        return $this->hasMany(VehiculoChofer::class, 'vehiculo_id', 'vehiculo_id');
    }
}
