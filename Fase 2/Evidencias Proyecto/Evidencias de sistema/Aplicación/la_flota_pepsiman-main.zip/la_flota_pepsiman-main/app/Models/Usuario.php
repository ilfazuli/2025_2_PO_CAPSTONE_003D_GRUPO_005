<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;

class Usuario extends Authenticatable
{
    use Notifiable;

    protected $table = 'usuarios';
    protected $primaryKey = 'usuario_id';
    public $timestamps = true; 

    protected $fillable = [
        'usuario_nombre', 'usuario_email', 'usuario_password', 'usuario_estado', 'usuario_telefono',
    ];

    protected $hidden = ['usuario_password', 'remember_token'];

    public function getEmailForPasswordReset()
    {
        return $this->usuario_email; 
    }
 
    public function getAuthPassword()
    {
        return $this->usuario_password;   
    }
    
    public function setUsuarioPasswordAttribute($value)
    {
        if (blank($value)) return;

        $info = password_get_info($value);
        $this->attributes['usuario_password'] =
            $info['algo'] === 0 ? Hash::make($value) : $value;
    }

    public function getAuthPasswordName()
    {
        return 'usuario_password';       
    }

    public function routeNotificationForMail($notification)
    {
        return $this->usuario_email;
    }

    public function roles()
    {
        
        return $this->belongsToMany(Role::class, 'roles_usuarios', 'usuario_id', 'rol_id');
    }
}
