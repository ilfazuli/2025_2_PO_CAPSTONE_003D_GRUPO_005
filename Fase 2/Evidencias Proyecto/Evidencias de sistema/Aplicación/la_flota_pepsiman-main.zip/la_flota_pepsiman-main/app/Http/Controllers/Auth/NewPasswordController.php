<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Hash;

class NewPasswordController extends Controller
{
    public function create(string $token)
    {
        return view('auth.passwords.reset', ['token' => $token]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'token'    => ['required'],
            'email'    => ['required','email'],
            'password' => ['required','string','min:8','confirmed'],
        ]);

        $status = Password::reset(
            [
                'token'                  => $request->token,
                'usuario_email'          => $request->email,      
                'password'               => $request->password,
                'password_confirmation'  => $request->password_confirmation,
            ],
            function ($user, $password) {
                $user->usuario_password = Hash::make($password); 
                $user->setRememberToken(str()->random(60));
                $user->save();
            }
        );

        return $status === Password::PASSWORD_RESET
            ? redirect()->route('login')->with('status', __($status))
            : back()->withErrors(['email' => __($status)]);
    }
}
