<?php

namespace App\Http\Controllers;

use App\Models\OrdenTrabajo;
use App\Models\Agendamiento;
use App\Models\Usuario;
use Illuminate\Http\Request;

class JefeTallerController extends Controller
{
    public function index()
    {
        return view('vista_jefe_taller');
    }

    // Cerrar OT (usamos route model binding)
    public function cerrar(OrdenTrabajo $ot)
    {
        if ($ot->estado === 'CERRADA') {
            return response()->json(['error' => 'La OT ya está cerrada'], 422);
        }


        $ot->estado    = 'CERRADA';
        $ot->cierre_ts = now();
        $ot->save();

        return response()->json(['ok' => true]);
    }

    // Asignar mecánico a OT
    public function asignarMecanico(Request $request, OrdenTrabajo $ot)
    {
        $data = $request->validate([
            'mecanico_id' => ['required', 'integer'],
        ]);

        $ot->mecanico_id = $data['mecanico_id'];
        $ot->estado      = 'EN_EJECUCION';
        $ot->save();

        return response()->json(['message' => 'Mecánico asignado correctamente']);
    }

    public function data(Request $request)
    {
        $baseOts = OrdenTrabajo::with(['vehiculo', 'mecanico']);

        // ---------- MECÁNICOS ----------
        // Filtramos usuarios que tienen rol MECANICO.
        // Usamos email como nombre visible para evitar problemas de columnas inexistentes.
        $mecanicos = Usuario::query()
            ->select('usuarios.usuario_id', 'usuarios.usuario_nombre')
            ->join('roles_usuarios', 'roles_usuarios.usuario_id', '=', 'usuarios.usuario_id')
            ->join('roles', 'roles.rol_id', '=', 'roles_usuarios.rol_id')
            ->where('roles.rol_code', 'MECANICO')
            ->orderBy('usuarios.usuario_nombre')
            ->get()
            ->map(function ($u) {
                return [
                    'id'     => $u->usuario_id,
                    'nombre' => $u->usuario_nombre ?? ('Usuario '.$u->usuario_id),
                ];
            });

        // ---------- KPIs ----------
        $kpiAbiertas = (clone $baseOts)
            ->whereIn('estado', ['ABIERTA', 'EN_EJECUCION'])
            ->count();

        $kpiEjecucion = (clone $baseOts)
            ->where('estado', 'EN_EJECUCION')
            ->count();

        $kpiFinalizadasHoy = (clone $baseOts)
            ->where('estado', 'CERRADA')
            ->whereDate('cierre_ts', now()->toDateString())
            ->count();

        // ---------- OTs ----------
        $ots = $baseOts
            ->orderByDesc('apertura_ts')
            ->take(100)
            ->get()
            ->map(function ($ot) {
                $estadoBruto = $ot->estado;
                $estadoMec   = $ot->estado_mecanico;

                // ----- LÓGICA DE ESTADO PARA LA UI -----
                if ($estadoBruto === 'CERRADA') {
                    $estadoUi    = 'finalizada';
                    $estadoLabel = 'Finalizada'; // ya cerrada por el jefe
                } elseif ($estadoMec === 'FINALIZADO_MEC') {
                    // Mecánico terminó, pero jefe aún no cierra
                    $estadoUi    = 'lista_cierre';
                    $estadoLabel = 'Finalizada mecánico';
                } elseif ($estadoBruto === 'EN_EJECUCION') {
                    $estadoUi    = 'en_proceso';
                    $estadoLabel = 'En proceso';
                } elseif ($estadoBruto === 'ABIERTA') {
                    $estadoUi    = 'pendiente';
                    $estadoLabel = 'Pendiente';
                } else {
                    $estadoUi    = strtolower($estadoBruto);
                    $estadoLabel = ucfirst(strtolower($estadoBruto));
                }

                $mec = $ot->mecanico;

                if ($mec) {
                    // si tiene nombre, usamos eso tal cual (ej: "Mecánico 1")
                    if (!empty($mec->usuario_nombre)) {
                        $nombreMec = $mec->usuario_nombre;
                    } else {
                        $nombreMec = 'Mecánico ' . $mec->usuario_id;
                    }
                } else {
                    $nombreMec = null;
                }

                return [
                    'id'             => $ot->id,
                    'folio'          => $ot->folio,
                    'patente'        => optional($ot->vehiculo)->vehiculo_patente ?? 'SIN PATENTE',
                    'prioridad'      => $ot->prioridad,
                    'estado'         => $estadoBruto,
                    'estado_ui'      => $estadoUi,
                    'estado_label'   => $estadoLabel,
                    'mecanico'       => $nombreMec,
                    'ready_to_close' => $estadoMec === 'FINALIZADO_MEC' && $estadoBruto !== 'CERRADA',
                ];
            });

        // ---------- AGENDA DEL DÍA ----------
        $agenda = Agendamiento::with(['vehiculo', 'tipoServicio'])
            ->whereDate('fecha', now()->toDateString())
            ->whereIn('estado', Agendamiento::ESTADOS_BLOQUEO)
            ->orderBy('hora_inicio')
            ->get()
            ->map(function ($ag) {
                $horaRaw = $ag->hora_inicio;
                $hora = $horaRaw ? substr((string) $horaRaw, 0, 5) : '';

                return [
                    'hora'    => $hora,
                    'patente' => optional($ag->vehiculo)->vehiculo_patente ?? 'SIN PATENTE',
                    'motivo'  => optional($ag->tipoServicio)->ts_nombre ?? 'Servicio agendado',
                ];
            });

        return response()->json([
            'kpis' => [
                'abiertas'       => $kpiAbiertas,
                'ejecucion'      => $kpiEjecucion,
                'finalizadasHoy' => $kpiFinalizadasHoy,
            ],
            'ots'       => $ots,
            'agenda'    => $agenda,
            'mecanicos' => $mecanicos,
        ]);
    }
}
