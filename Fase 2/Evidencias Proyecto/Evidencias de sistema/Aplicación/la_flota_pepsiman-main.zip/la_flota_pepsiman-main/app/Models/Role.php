<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $table = 'roles';
    protected $primaryKey = 'rol_id';

    protected $fillable = ['rol_code', 'rol_nombre', 'rol_descripcion'];

    public function usuarios() {
        return $this->belongsToMany(Usuario::class, 'roles_usuarios', 'rol_id', 'usuario_id')
                    ->withTimestamps();
    }
}
