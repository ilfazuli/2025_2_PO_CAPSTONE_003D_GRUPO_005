<?php

namespace App\Http\Controllers\Chofer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema; 

class ReservaController extends Controller
{
    public function index(Request $request)
    {
        $userId = Auth::id();

        $q = DB::table('vehiculos as v')
            ->join('vehiculos_choferes as vc', 'vc.vehiculo_id', '=', 'v.vehiculo_id')
            ->where('vc.usuario_id', $userId);

        // Solo aplica el filtro si la columna existe
        if (Schema::hasColumn('vehiculos_choferes', 'fecha_fin')) {
            $q->whereNull('vc.fecha_fin');
        }

        $vehiculos = $q->select('v.vehiculo_id', 'v.vehiculo_patente', 'v.vehiculo_marca', 'v.vehiculo_modelo')
                       ->orderBy('v.vehiculo_patente')
                       ->get();

        // Fallback si aún usas vehiculos.usuario_id
        if ($vehiculos->isEmpty()) {
            $vehiculos = DB::table('vehiculos')
                ->where('usuario_id', $userId)
                ->select('vehiculo_id','vehiculo_patente','vehiculo_marca','vehiculo_modelo')
                ->orderBy('vehiculo_patente')
                ->get();
        }

        // Motivos activos
        $motivos = DB::table('tipo_servicios')
            ->where('ts_activo', 1)
            ->select('ts_id','ts_nombre','duracion_minutos')
            ->orderBy('ts_nombre')
            ->get();

        return view('vista_chofer_reserva', compact('vehiculos','motivos'));
    }

    public function slots(Request $request)
    {
        $request->validate([
            'fecha' => ['required','date_format:Y-m-d'],
            'ts_id' => ['required','integer','exists:tipo_servicios,ts_id'],
        ]);

        $fecha = $request->fecha;
        $tsId  = (int) $request->ts_id;

        [$oH, $oM] = array_map('intval', explode(':', config('agenda.open',  '08:00')));
        [$cH, $cM] = array_map('intval', explode(':', config('agenda.close', '18:00')));
        $step      = (int) config('agenda.step', 30);
        $bloqSt    = (array) config('agenda.blocking_status', ['PENDIENTE','CONFIRMADO']);

        $duracion = (int) DB::table('tipo_servicios')
            ->where('ts_id',$tsId)
            ->value('duracion_minutos') ?: 60;

        $ocupados = DB::table('agendamientos')
            ->where('fecha', $fecha)
            ->whereIn('estado', $bloqSt)
            ->select('hora_inicio','hora_fin')
            ->get();

        $toMin = fn($h,$m) => $h*60 + $m;
        $inicioMin  = $toMin($oH, $oM);
        $cierreMin  = $toMin($cH, $cM);

        $bloques = $ocupados->map(function($r) use ($toMin) {
            [$hiH,$hiM] = array_map('intval', explode(':', $r->hora_inicio));
            [$hfH,$hfM] = array_map('intval', explode(':', $r->hora_fin));
            return [$toMin($hiH,$hiM), $toMin($hfH,$hfM)];
        })->toArray();

        $slots = [];
        for ($ini = $inicioMin; $ini + $duracion <= $cierreMin; $ini += $step) {
            $fin = $ini + $duracion;

            $choca = false;
            foreach ($bloques as [$oIni, $oFin]) {
                if ($ini < $oFin && $fin > $oIni) { $choca = true; break; }
            }

            if (!$choca) {
                $slots[] = sprintf('%02d:%02d', intdiv($ini,60), $ini%60);
            }
        }

        return response()->json([
            'duracion' => $duracion,
            'slots'    => $slots,
        ]);
    }

    public function store(Request $request)
    {
        $userId = Auth::id();

        $data = $request->validate([
            'vehiculo_id'       => ['required','integer','exists:vehiculos,vehiculo_id'],
            'tipo_servicio_id'  => ['required','integer','exists:tipo_servicios,ts_id'],
            'fecha'             => ['required','date_format:Y-m-d'],
            'hora_inicio'       => ['required','date_format:H:i'],
            'hora_fin'          => ['nullable','date_format:H:i'], // se recalcula
        ]);

        $esDelChofer = DB::table('vehiculos_choferes')
            ->where('vehiculo_id', $data['vehiculo_id'])
            ->where('usuario_id', $userId)
            ->whereNull('hasta_ts')
            ->exists();

        if (!$esDelChofer) {
            $esDelChofer = DB::table('vehiculos')
                ->where('vehiculo_id', $data['vehiculo_id'])
                ->where('usuario_id', $userId)
                ->exists();
        }
        abort_unless($esDelChofer, 403, 'Vehículo no asociado al chofer.');

        $duracion = (int) DB::table('tipo_servicios')
            ->where('ts_id',$data['tipo_servicio_id'])
            ->value('duracion_minutos') ?: 60;

        [$h,$m] = array_map('intval', explode(':', $data['hora_inicio']));
        $finMin = $h*60 + $m + $duracion;
        $horaFin = sprintf('%02d:%02d', intdiv($finMin,60), $finMin%60);

        $bloqSt = (array) config('agenda.blocking_status', ['PENDIENTE','CONFIRMADO']);

        $choca = DB::table('agendamientos')
            ->where('fecha', $data['fecha'])
            ->whereIn('estado', $bloqSt)
            ->where(function($q) use ($data, $horaFin) {
                $q->where(function($qq) use ($data, $horaFin) {
                    $qq->where('hora_inicio','<', $horaFin)
                       ->where('hora_fin','>', $data['hora_inicio']);
                });
            })
            ->exists();

        if ($choca) {
            return back()
                ->withErrors(['hora_inicio' => 'La hora seleccionada ya no está disponible.'])
                ->withInput();
        }

        $canal = config('agenda.default_channel', 'WEB_CHOFER');
        $folio = DB::transaction(function () use ($data, $horaFin, $userId, $canal) {
            $fecha = $data['fecha'];
            $secuencia = (int) DB::table('agendamientos')
                ->where('fecha', $fecha)
                ->lockForUpdate()
                ->count() + 1;

            $folio = str_replace('-', '', $fecha) . '-' . str_pad($secuencia, 4, '0', STR_PAD_LEFT);

            DB::table('agendamientos')->insert([
                'vehiculo_id'      => $data['vehiculo_id'],
                'usuario_id'       => $userId,
                'tipo_servicio_id' => $data['tipo_servicio_id'],
                'fecha'            => $fecha,
                'hora_inicio'      => $data['hora_inicio'],
                'hora_fin'         => $horaFin,
                'estado'           => 'PENDIENTE',
                'canal'            => $canal,
                'folio'            => $folio,
                'created_at'       => now(),
                'updated_at'       => now(),
            ]);

            return $folio;
        });

        return redirect()
            ->route('chofer.reserva')
            ->with('ok', "Cita reservada para {$data['fecha']} a las {$data['hora_inicio']} (Folio: {$folio}).");
    }
}
