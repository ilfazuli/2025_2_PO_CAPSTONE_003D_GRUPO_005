<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('agendamientos', function (Blueprint $table) {
            $table->bigIncrements('agendamiento_id');

            // FK básicas
            $table->unsignedBigInteger('vehiculo_id');
            $table->unsignedBigInteger('usuario_id');       
            $table->unsignedBigInteger('tipo_servicio_id');

            // Fecha y ventana de tiempo
            $table->date('fecha');
            $table->time('hora_inicio');
            $table->time('hora_fin');

            // Estado/canal
            $table->string('estado', 20)->default('PENDIENTE');
            $table->string('canal', 30)->default('WEB_CHOFER');

            //  Folio único
            $table->string('folio', 24)->unique()->nullable();

            $table->timestamps();

            // Índices prácticos
            $table->index(['fecha', 'hora_inicio', 'estado'], 'agend_fecha_hora_estado_idx');
            $table->index(['vehiculo_id', 'fecha'], 'agend_vehiculo_fecha_idx');

            // FKs 
            $table->foreign('vehiculo_id')->references('vehiculo_id')->on('vehiculos')
                  ->cascadeOnUpdate()->restrictOnDelete();

            $table->foreign('usuario_id')->references('usuario_id')->on('usuarios')
                  ->cascadeOnUpdate()->restrictOnDelete();

            $table->foreign('tipo_servicio_id')->references('ts_id')->on('tipo_servicios')
                  ->cascadeOnUpdate()->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agendamientos');
    }
};
