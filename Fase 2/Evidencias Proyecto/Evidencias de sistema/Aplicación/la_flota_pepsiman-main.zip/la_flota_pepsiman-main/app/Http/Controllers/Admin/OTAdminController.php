<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Models\OrdenTrabajo;
use App\Models\Usuario;
use Illuminate\Support\Facades\DB;

class OtAdminController extends Controller
{
    /**
     * Vista principal de visualización de OT para el ADMIN.
     */
    public function index(Request $request)
    {
        // Filtros simples
        $estado     = $request->get('estado');       // ABIERTA / CERRADA / etc.
        $mecanicoId = $request->get('mecanico_id');  // id del mecánico
        $folio      = trim((string) $request->get('folio', ''));

        // Query base de OT con relaciones típicas
        $query = OrdenTrabajo::with(['vehiculo', 'mecanico'])
            ->orderByDesc('apertura_ts');

        if ($estado) {
            $query->where('estado', $estado);
        }

        if ($mecanicoId) {
            $query->where('mecanico_id', $mecanicoId);
        }

        if ($folio !== '') {
            $query->where('folio', 'LIKE', "%{$folio}%");
        }

        // Paginado para la tabla
        $ots = $query->paginate(20)->withQueryString();

        // --- Datos para gráficos ---
        $chartQuery = OrdenTrabajo::query();

        if ($estado) {
            $chartQuery->where('estado', $estado);
        }
        if ($mecanicoId) {
            $chartQuery->where('mecanico_id', $mecanicoId);
        }
        if ($folio !== '') {
            $chartQuery->where('folio', 'LIKE', "%{$folio}%");
        }

        // OT por estado
        $otsPorEstado = $chartQuery->select('estado', DB::raw('count(*) as total'))
            ->groupBy('estado')
            ->orderBy('estado')
            ->get();

        // OT cerradas por mecánico        
        $otsPorMecanico = OrdenTrabajo::selectRaw('mecanico_id, COUNT(*) as total')
                ->where('estado', 'CERRADA')
                ->when($mecanicoId, fn($q) => $q->where('mecanico_id', $mecanicoId))
                ->when($folio !== '', fn($q) => $q->where('folio', 'LIKE', "%{$folio}%"))
                ->groupBy('mecanico_id')
                ->get();      
                
        $mecanicoIds = $otsPorMecanico->pluck('mecanico_id')->filter()->unique()->all();
        $mecs = Usuario::whereIn('usuario_id', $mecanicoIds)->get()->keyBy('usuario_id');

        $otsPorMecanico = $otsPorMecanico->map(function($r) use ($mecs) {
            return [
                'mecanico_id' => $r->mecanico_id,
                'nombre'      => $mecs->get($r->mecanico_id)?->usuario_nombre ?? 'Sin nombre',
                'total'       => (int) $r->total,
            ];
        })->values();
                

        // === Mini cuadro: conteo de OT cerradas por mecánico ===
        $rankingRaw = OrdenTrabajo::selectRaw('mecanico_id, COUNT(*) as total_cerradas')
            ->where('estado', 'CERRADA')
            ->whereNotNull('mecanico_id')
            ->groupBy('mecanico_id')
            ->orderByDesc('total_cerradas')
            ->get();

        // Traemos los mecánicos correspondientes
        $mecanicos = Usuario::whereIn('usuario_id', $rankingRaw->pluck('mecanico_id'))
            ->get()
            ->keyBy('usuario_id');

        // Armamos un arreglo listo para la vista
        $ranking = $rankingRaw->map(function ($row) use ($mecanicos) {
            $mec = $mecanicos->get($row->mecanico_id);
            return [
                'mecanico_id'    => $row->mecanico_id,
                'nombre'         => $mec?->usuario_nombre ?? 'Sin nombre',
                'email'          => $mec?->usuario_email ?? '',
                'total_cerradas' => (int) $row->total_cerradas,
            ];
        });

        // Lista de mecánicos para el filtro
        $mecanicosFiltro = Usuario::whereHas('roles', function ($q) {
                $q->where('rol_nombre', 'Mecánico');
            })
            ->orderBy('usuario_nombre')
            ->get();

        return view('vista_admin_ots', [
            'ots'             => $ots,
            'ranking'         => $ranking,
            'mecanicosFiltro' => $mecanicosFiltro,
            'estado'          => $estado,
            'mecanicoId'      => $mecanicoId,
            'folio'           => $folio,
            'otsPorEstado'    => $otsPorEstado,
            'otsPorMecanico'  => $otsPorMecanico,
        ]); 
    }

    /**
     * Exportar las OT a un CSV para abrir en Excel.
     */
    public function exportCsv(Request $request)
    {
        $estado     = $request->get('estado');
        $mecanicoId = $request->get('mecanico_id');
        $folio      = trim((string) $request->get('folio', ''));

        $query = OrdenTrabajo::with(['vehiculo', 'mecanico'])
            ->orderByDesc('apertura_ts');

        if ($estado) {
            $query->where('estado', $estado);
        }

        if ($mecanicoId) {
            $query->where('mecanico_id', $mecanicoId);
        }

        if ($folio !== '') {
            $query->where('folio', 'LIKE', "%{$folio}%");
        }

        $filename = 'ordenes_trabajo_' . now()->format('Ymd_His') . '.csv';

        $headers = [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        // Stream para no reventar memoria
        return Response::stream(function () use ($query) {
            $out = fopen('php://output', 'w');

            
            fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

            $delim = ';';
            
            // Encabezados
            fputcsv($out, [
                'Folio',
                'Estado',
                'Apertura',
                'Cierre',
                'Prioridad',
                'Origen',
                'Patente',
                'Mecánico',
            ], $delim);

            $query->chunk(200, function ($chunk) use ($out, $delim) {
                foreach ($chunk as $ot) {
                    fputcsv($out, [
                        $ot->folio,
                        $ot->estado,
                        optional($ot->apertura_ts)->format('Y-m-d H:i'),
                        optional($ot->cierre_ts)->format('Y-m-d H:i'),
                        $ot->prioridad,
                        $ot->origen,
                        optional($ot->vehiculo)->vehiculo_patente ?? '',
                        optional($ot->mecanico)->usuario_nombre ?? '',
                    ], $delim);
                }
            });

            fclose($out);
        }, 200, $headers);
    }
}
