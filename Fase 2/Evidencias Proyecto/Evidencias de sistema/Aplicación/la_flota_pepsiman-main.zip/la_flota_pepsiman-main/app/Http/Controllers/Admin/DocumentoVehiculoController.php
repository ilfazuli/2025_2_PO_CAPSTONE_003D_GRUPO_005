<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Documento;
use App\Models\Vehiculo;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class DocumentoVehiculoController extends Controller
{
    /** Lista documentos de un vehículo  */
    public function index($vehiculoId)
    {
        $vehiculo = Vehiculo::findOrFail($vehiculoId);

        $docs = Documento::where('vehiculo_id', $vehiculo->vehiculo_id)
            ->orderByDesc('fecha_vencimiento')
            ->orderByDesc('created_at')
            ->get()
            ->map(function ($d) {
                return [
                    'id'                => $d->id,
                    'tipo'              => $d->tipo,
                    'tipo_label'        => $this->labelTipo($d->tipo),
                    'descripcion'       => $d->descripcion,
                    'fecha_emision'     => optional($d->fecha_emision)->format('Y-m-d'),
                    'fecha_vencimiento' => optional($d->fecha_vencimiento)->format('Y-m-d'),
                    'archivo_url' => $d->archivo_path? asset('storage/'.$d->archivo_path): null, 
                ];
            });

        return response()->json($docs);
    }

    /** Crear documento para un vehículo */
    public function store(Request $request, $vehiculoId)
    {
        $vehiculo = Vehiculo::findOrFail($vehiculoId);

        $data = $request->validate([
            'tipo'             => 'required|string|max:50',
            'descripcion'      => 'nullable|string|max:255',
            'fecha_emision'    => 'nullable|date',
            'fecha_vencimiento'=> 'nullable|date|after_or_equal:fecha_emision',
            'archivo'          => 'required|file|max:8192|mimes:jpg,jpeg,png,pdf',
        ]);

        DB::beginTransaction();
        try {
            $path = $request->file('archivo')->store('documentos_vehiculos', 'public');

            Documento::create([
                'vehiculo_id'      => $vehiculo->vehiculo_id,
                'tipo'             => $data['tipo'],
                'descripcion'      => $data['descripcion'] ?? null,
                'archivo_path'     => $path,
                'fecha_emision'    => $data['fecha_emision'] ?? null,
                'fecha_vencimiento'=> $data['fecha_vencimiento'] ?? null,
            ]);

            DB::commit();
            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al guardar documento: '.$e->getMessage(),
            ], 500);
        }
    }

    /** Actualizar documento existente */
    public function update(Request $request, $id)
    {
        $doc = Documento::findOrFail($id);

        $data = $request->validate([
            'tipo'             => 'sometimes|required|string|max:50',
            'descripcion'      => 'nullable|string|max:255',
            'fecha_emision'    => 'nullable|date',
            'fecha_vencimiento'=> 'nullable|date|after_or_equal:fecha_emision',
            'archivo'          => 'nullable|file|max:8192|mimes:jpg,jpeg,png,pdf',
        ]);

        DB::beginTransaction();
        try {
            if (isset($data['tipo'])) {
                $doc->tipo = $data['tipo'];
            }
            $doc->descripcion       = $data['descripcion'] ?? $doc->descripcion;
            $doc->fecha_emision     = $data['fecha_emision'] ?? $doc->fecha_emision;
            $doc->fecha_vencimiento = $data['fecha_vencimiento'] ?? $doc->fecha_vencimiento;

            if ($request->hasFile('archivo')) {
                if ($doc->archivo_path) {
                    Storage::disk('public')->delete($doc->archivo_path);
                }
                $doc->archivo_path = $request->file('archivo')->store('documentos_vehiculos', 'public');
            }

            $doc->save();
            DB::commit();
            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al actualizar documento: '.$e->getMessage(),
            ], 500);
        }
    }

    /** Eliminar documento */
    public function destroy($id)
    {
        $doc = Documento::findOrFail($id);

        DB::beginTransaction();
        try {
            if ($doc->archivo_path) {
                Storage::disk('public')->delete($doc->archivo_path);
            }
            $doc->delete();
            DB::commit();
            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar documento: '.$e->getMessage(),
            ], 500);
        }
    }

    private function labelTipo(string $tipo): string
    {
        return match ($tipo) {
            'PERMISO_CIRCULACION' => 'Permiso de circulación',
            'REVISION_TECNICA'    => 'Revisión técnica',
            'SEGURO_OBLIGATORIO'  => 'Seguro obligatorio (SOAP)',
            'PADRON'              => 'Padrón',
            'GASES'              => 'Gases',
            'OTRO'                => 'Otro',
            default               => $tipo,
        };
    }
}
