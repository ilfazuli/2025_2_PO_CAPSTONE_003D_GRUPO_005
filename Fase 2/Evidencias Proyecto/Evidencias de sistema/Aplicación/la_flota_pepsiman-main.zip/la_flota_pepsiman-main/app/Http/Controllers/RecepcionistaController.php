<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Checkin;
use App\Models\OrdenTrabajo;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class RecepcionistaController extends Controller
{
    /**
     * Lista de solicitudes de ingreso y procesadas para el recepcionista.
     */
    public function index(Request $request)
    {
        $fecha = $request->input('fecha', Carbon::today()->toDateString());

        // Solicitudes pendientes de revisión
        $pendientes = Checkin::with([
                'vehiculo.chofer',
                'agendamiento',      
                'agendamiento.usuario', 
            ])
            ->whereDate('ingreso_ts', $fecha)
            ->where('estado_recepcion', 'PENDIENTE')
            ->orderBy('ingreso_ts', 'asc')
            ->get();

        // Historial de aceptadas / rechazadas
        $historial = Checkin::with([
                'vehiculo.chofer',
                'agendamiento',
                'agendamiento.usuario',
            ])
            ->whereDate('ingreso_ts', $fecha)
            ->whereIn('estado_recepcion', ['ACEPTADA', 'RECHAZADA'])
            ->orderByDesc('ingreso_ts')
            ->limit(20)
            ->get();

        return view('vista_recepcionista', compact('pendientes', 'historial', 'fecha'));
    }

    /**
     * Aceptar una solicitud de ingreso:
     *  - Cambia estado_recepcion a ACEPTADA
     *  - Crea la Orden de Trabajo (OT)
     */
    public function aceptar(Request $request, $id)
    {
        $checkin = Checkin::with(['vehiculo', 'agendamiento'])->findOrFail($id);

        // Si ya no está pendiente, no permitimos reprocesar
        if ($checkin->estado_recepcion !== 'PENDIENTE') {
            return back()->with('error', 'Esta solicitud ya fue procesada.');
        }

        // Por seguridad, si no hay vehículo asociado, no creamos OT
        if (!$checkin->vehiculo_id) {
            return back()->with('error', 'No se puede crear una OT porque el check-in no tiene vehículo asociado.');
        }

        DB::beginTransaction();
        try {
            // Marcar como aceptada por recepción
            $checkin->estado_recepcion = 'ACEPTADA';
            $checkin->save();

            // CREACIÓN DE LA ORDEN DE TRABAJO (OT)
            $folio = 'OT-' . now()->format('Ymd-His') . '-' . strtoupper(Str::random(4));

            OrdenTrabajo::create([
                'folio'           => $folio,
                'vehiculo_id'     => $checkin->vehiculo_id,
                'agendamiento_id' => $checkin->agendamiento_id, 
                'estado'          => 'ABIERTA',
                'apertura_ts'     => now(),
                'prioridad'       => 3,
                'origen'          => $checkin->agendamiento_id ? 'AGENDA' : 'SIN_AGENDA',
            ]);

            DB::commit();

            return back()->with('success', 'Solicitud aceptada y Orden de Trabajo creada.');
        } catch (\Throwable $e) {
            DB::rollBack();
            return back()->with('error', 'Error al crear la OT: '.$e->getMessage());
        }
    }

    /**
     * Rechazar una solicitud de ingreso:
     *  - Cambia estado_recepcion a RECHAZADA
     *  - No crea OT
     */
    public function rechazar(Request $request, $id)
    {
        $checkin = Checkin::findOrFail($id);

        if ($checkin->estado_recepcion !== 'PENDIENTE') {
            return back()->with('error', 'Esta solicitud ya fue procesada.');
        }

        $checkin->estado_recepcion = 'RECHAZADA';
        $checkin->save();

        return back()->with('success', 'Solicitud rechazada correctamente.');
    }
}
