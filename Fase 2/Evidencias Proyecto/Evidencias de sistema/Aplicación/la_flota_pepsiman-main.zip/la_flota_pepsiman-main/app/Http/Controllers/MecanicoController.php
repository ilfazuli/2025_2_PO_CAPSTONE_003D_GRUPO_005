<?php

namespace App\Http\Controllers;

use App\Models\OrdenTrabajo;
use App\Models\OrdenTrabajoTarea;
use App\Models\OrdenTrabajoFoto;
use App\Models\TipoServicio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class MecanicoController extends Controller
{
    // ====================== VISTA PRINCIPAL ======================
    public function index()
    {
        $user = Auth::user();

        $ots = OrdenTrabajo::with(['vehiculo', 'agendamiento.tipoServicio'])
            ->where('mecanico_id', $user->usuario_id)
            ->whereIn('estado', ['ABIERTA', 'EN_EJECUCION'])
            ->where(function ($q) {
                // solo mostrar OTs que el mecánico NO ha marcado como finalizadas
                $q->whereNull('estado_mecanico')
                ->orWhereIn('estado_mecanico', ['PENDIENTE', 'EN_TRABAJO', 'PAUSADO']);
            })
            ->orderByDesc('apertura_ts')
            ->get()
            ->map(function ($ot) use ($user) {
                $row = \App\Models\OrdenTrabajoTarea::where('orden_trabajo_id', $ot->id)
                    ->where('mecanico_id', $user->usuario_id)
                    ->where('estado', 'en_proceso')
                    ->orderByDesc('inicio_ts')
                    ->first();

                $ot->ultimo_inicio_tramo = $row?->inicio_ts ? (string) $row->inicio_ts : null;

                return $ot;
            });

        return view('vista_mecanico', compact('ots'));
    }


    // ====================== HISTORIAL ======================
    public function historial()
    {
        $user = Auth::user();

        $ots = OrdenTrabajo::with(['vehiculo', 'agendamiento.tipoServicio'])
            ->where('mecanico_id', $user->usuario_id)
            ->where(function ($q) {
                $q->where('estado_mecanico', 'FINALIZADO_MEC')
                  ->orWhere('estado', 'CERRADA');
            })
            ->orderByDesc('apertura_ts')
            ->get();

        return view('vista_mecanico_historial_ot', compact('ots'));
    }

    // ====================== TAREA PRINCIPAL ======================
    protected function tareaPrincipal(OrdenTrabajo $ot): OrdenTrabajoTarea
    {
        $tsId = optional(optional($ot->agendamiento)->tipoServicio)->ts_id;

        if (!$tsId) {
            $tipo = TipoServicio::where('ts_activo', true)
                ->orderBy('ts_id')
                ->first();

            if (!$tipo) {
                abort(422, 'No hay tipos de servicio configurados en el sistema.');
            }

            $tsId = $tipo->ts_id;
        }

        $tarea = OrdenTrabajoTarea::where('orden_trabajo_id', $ot->id)
            ->where('tipo_servicio_id', $tsId)
            ->where('mecanico_id', $ot->mecanico_id)
            ->orderBy('id')
            ->first();

        if (!$tarea) {
            $tarea = OrdenTrabajoTarea::create([
                'orden_trabajo_id' => $ot->id,
                'tipo_servicio_id' => $tsId,
                'mecanico_id'      => $ot->mecanico_id,
                'estado'           => 'pendiente',
            ]);
        }

        return $tarea;
    }

    // ====================== INICIAR ======================
    public function iniciarTrabajo(OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $tarea = $this->tareaPrincipal($ot);

        if ($tarea->estado !== 'en_proceso') {
            $tarea->inicio_ts = now();
            $tarea->estado    = 'en_proceso';
            $tarea->save();
        }

        $ot->estado          = 'EN_EJECUCION';
        $ot->estado_mecanico = 'EN_TRABAJO';
        $ot->save();

        return response()->json(['ok' => true]);
    }

    // ====================== PAUSAR ======================
    public function pausarTrabajo(OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $tarea = $this->tareaPrincipal($ot);

        if ($tarea->inicio_ts && $tarea->estado === 'en_proceso') {
            $inicio = Carbon::parse($tarea->inicio_ts);
            $fin    = now();
            $min    = $inicio->diffInMinutes($fin);

            $ot->tiempo_trabajo_min = ($ot->tiempo_trabajo_min ?? 0) + $min;
            $ot->save();

            $tarea->fin_ts = $fin;
        }

        $tarea->estado = 'pausada';
        $tarea->save();

        $ot->estado_mecanico = 'PAUSADO';
        $ot->save();

        return response()->json(['ok' => true]);
    }

    // ====================== REANUDAR ======================
    public function reanudarTrabajo(OrdenTrabajo $ot)
    {
        return $this->iniciarTrabajo($ot);
    }

    // ====================== FINALIZAR ======================
    public function finalizarTrabajo(OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $tarea = $this->tareaPrincipal($ot);

        if ($tarea->inicio_ts && $tarea->estado === 'en_proceso') {
            $inicio = Carbon::parse($tarea->inicio_ts);
            $fin    = now();
            $min    = $inicio->diffInMinutes($fin);

            $ot->tiempo_trabajo_min = ($ot->tiempo_trabajo_min ?? 0) + $min;
            $ot->save();

            $tarea->fin_ts = $fin;
        }

        $tarea->estado = 'finalizada';
        $tarea->save();

        $ot->estado_mecanico = 'FINALIZADO_MEC';
        $ot->save();

        return response()->json(['ok' => true]);
    }

    // ====================== COMENTARIO ======================
    public function guardarComentario(Request $request, OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $data = $request->validate([
            'texto' => ['required', 'string', 'max:2000'],
        ]);

        $tarea = $this->tareaPrincipal($ot);

        $prefijo = now()->format('d-m H:i');
        $linea   = "[{$prefijo}] {$data['texto']}";

        $tarea->nota = trim(($tarea->nota ?? '') . "\n" . $linea);
        $tarea->save();

        return response()->json(['ok' => true]);
    }

    // ====================== INFO VEHÍCULO ======================
    public function info(OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $tarea = OrdenTrabajoTarea::where('orden_trabajo_id', $ot->id)
            ->where('mecanico_id', $user->usuario_id)
            ->orderBy('id')
            ->first();

        $comentarios = [];
        if ($tarea && $tarea->nota) {
            $comentarios = preg_split("/\r\n|\n|\r/", $tarea->nota);
        }

        $veh = $ot->vehiculo;

        //  Traer fotos asociadas a la OT
        $fotos = OrdenTrabajoFoto::where('orden_trabajo_id', $ot->id)
            ->orderBy('created_at')
            ->get()
            ->map(function ($f) {
                return [
                    'id'   => $f->id,
                    'url'  => asset('storage/' . $f->path),
                    'nota' => $f->nota,
                    'tipo' => $f->tipo,
                ];
            })
            ->values()
            ->all();

        return response()->json([
            'ot' => [
                'id'      => $ot->id,
                'folio'   => $ot->folio,
                'patente' => optional($veh)->vehiculo_patente ?? 'SIN PATENTE',
                'marca'   => optional($veh)->vehiculo_marca ?? '',
                'modelo'  => optional($veh)->vehiculo_modelo ?? '',
                'anio'    => optional($veh)->anio ?? '',
                'motivo'  => optional(optional($ot->agendamiento)->tipoServicio)->ts_nombre
                            ?? $ot->origen
                            ?? 'Trabajo asignado',
            ],
            'comentarios' => $comentarios,
            'fotos'       => $fotos,
        ]);
    }


    // ====================== SUBIR FOTO ======================
    public function subirFoto(Request $request, OrdenTrabajo $ot)
    {
        $user = Auth::user();
        if ($ot->mecanico_id !== $user->usuario_id) {
            return response()->json(['error' => 'OT no asignada a este mecánico'], 403);
        }

        $data = $request->validate([
            'foto' => ['required', 'image', 'max:4096'],
            'nota' => ['nullable', 'string', 'max:2000'],
            'tipo' => ['nullable', 'string', 'max:30'],
        ]);

        $path = $request->file('foto')->store('ot_fotos', 'public');

        $foto = OrdenTrabajoFoto::create([
            'orden_trabajo_id' => $ot->id,
            'vehiculo_id'      => $ot->vehiculo_id,
            'mecanico_id'      => $user->usuario_id,
            'tipo'             => $data['tipo'] ?? 'PROCESO',
            'path'             => $path,
            'nota'             => $data['nota'] ?? null,
        ]);

        return response()->json([
            'ok'   => true,
            'id'   => $foto->id,
            'url'  => asset('storage/' . $path),
            'nota' => $foto->nota,
        ]);
    }
}
