import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js', 
                'resources/css/guardia.css', 'resources/js/guardia.js',
                'resources/css/recepcionista.css', 'resources/js/recepcionista.js',
                'resources/css/chofer.css', 'resources/js/chofer.js',
                'resources/css/chofer_reserva.css', 'resources/js/chofer_reserva.js',
                'resources/css/chofer_documentacion.css', 'resources/js/chofer_documentacion.js',
                'resources/css/admin.css', 'resources/js/admin.js',
                'resources/css/admin_usuario.css', 'resources/js/admin_usuario.js',
                'resources/css/admin_vehiculo.css', 'resources/js/admin_vehiculo.js',
                'resources/css/login.css', 'resources/js/login.js',
                'resources/css/navbar.css', 'resources/js/navbar.js',
                'resources/css/password_email.css', 'resources/js/password_email.js',
                'resources/css/vista_mecanico.css', 'resources/js/vista_mecanico.js', 
                'resources/css/vista_mecanico_historial_ot.css', 'resources/js/vista_mecanico_historial_ot.js',  
                'resources/css/password_reset.css', 'resources/js/password_reset.js',
                'resources/css/vista_mecanico_solicitar.css', 'resources/js/vista_mecanico_solicitar.js',
                'resources/css/admin_ots.css', 'resources/js/admin_ots.js',
                'resources/css/vista_jefe_taller.css', 'resources/js/vista_jefe_taller.js',  
                'resources/css/vista_mecanico_historial_ot.css', 'resources/js/vista_mecanico_historial_ot.js',
                   ],

                
            refresh: true,
        }),
        tailwindcss(),
    ],
});
