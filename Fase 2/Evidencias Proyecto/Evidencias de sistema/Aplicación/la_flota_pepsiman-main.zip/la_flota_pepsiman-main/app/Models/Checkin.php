<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Vehiculo;
use App\Models\Usuario;
use App\Models\Agendamiento;

class Checkin extends Model
{
    use HasFactory;

    protected $table = 'checkins';
    protected $primaryKey = 'checkin_id';
    public $timestamps = true;

    protected $fillable = [
        'vehiculo_id',
        'usuario_id',    
        'agendamiento_id',
        'fotos_json',
        'ingreso_ts',
        'salida_ts',
        'estado_recepcion',
    ];

    protected $casts = [
        'ingreso_ts' => 'datetime',
        'salida_ts'  => 'datetime',
        'fotos_json' => 'array',
    ];

    // Vehículo al que corresponde el check-in
    public function vehiculo()
    {
        return $this->belongsTo(Vehiculo::class, 'vehiculo_id', 'vehiculo_id');
    }

    // Guardia que registró el ingreso 
    public function guardia()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id', 'usuario_id');
    }

    // Reserva asociada 
    public function agendamiento()
    {
        return $this->belongsTo(Agendamiento::class, 'agendamiento_id', 'agendamiento_id');
    }
}
